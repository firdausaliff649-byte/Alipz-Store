const numberAllowed = ["601130538675"]; 

global.prefix = [".", "#"]; 

global.jeda = 100; 

global.name_script = "𝗗𝗔𝗠𝗫 𝗕𝗟𝗔𝗦𝗧𝗘𝗥 𝗩𝟰.𝟬";

global.version = "4.0";

global.thumbnail = "https://files.catbox.moe/ntv9i1.jpg"
;

global.autobcgc = {
  hidetag: false, 
  jedaPutaran: 600000, 
};

export { numberAllowed };