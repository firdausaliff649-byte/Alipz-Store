/*  
   ⚙️ 𝗗𝗔𝗠𝗫 𝗕𝗟𝗔𝗦𝗧𝗘𝗥 𝗕𝗬 𝗗𝗔𝗠𝗫 ⚙️
   Plugin: AUTO REPLY 
*/

import clc from "cli-color";
import { readAutoReplyConfig, saveAutoReplyConfig, autoRepliedUsers } from "../lib/utils.js";

async function autoreply(sock, sender, messages, key, messageEvent) {
  const body  = messages.trim();
  const parts = body.split(" ");
  const sub   = (parts[1] || "").toLowerCase();
  const rest  = parts.slice(2).join(" ").trim();

  if (!sub || sub === "status") {
    const cfg = readAutoReplyConfig();
    return sock.sendMessage(sender, {
      text:
`📊 *STATUS AUTO REPLY*

╔═〔 ℹ️ 𝗜𝗡𝗙𝗢 〕══╗
║ 🔘 Status   : ${cfg.enabled ? "🟢 AKTIF" : "🔴 TIDAK AKTIF"}
║ 💬 Teks     : ${cfg.text ? cfg.text.substring(0, 80) + (cfg.text.length > 80 ? "..." : "") : "(belum ditetapkan)"}
║ 👥 Dah reply: ${autoRepliedUsers.size} pengguna (sesi ini)
╚═════════════════╝

📝 *Command:*
• \`.autoreply on\`      — Aktifkan
• \`.autoreply off\`     — Nyahaktifkan
• \`.autoreply set <teks>\` — Tetapkan mesej
• \`.autoreply clear\`   — Reset senarai replied
• \`.autoreply status\`  — Semak status

© ᴅᴀᴍx ʙʟᴀsᴛᴇʀ | ɴᴇxᴛ-ɢᴇɴ ʙᴏᴛ`
    });
  }

  if (sub === "on") {
    const cfg = readAutoReplyConfig();
    if (cfg.enabled) {
      return sock.sendMessage(sender, { text: "⚠️ Auto Reply sudah aktif." });
    }
    if (!cfg.text) {
      return sock.sendMessage(sender, {
        text: "⚠️ Sila tetapkan teks dahulu!\n\n*Contoh:* `.autoreply set Hai! Sila hubungi owner.`"
      });
    }
    cfg.enabled = true;
    saveAutoReplyConfig(cfg);
    console.log(clc.green("[AutoReply] Diaktifkan."));
    return sock.sendMessage(sender, {
      text: `✅ *AUTO REPLY DIAKTIFKAN*\n\n💬 Teks: _${cfg.text}_\n\n_Bot akan balas sekali sahaja bagi setiap pengguna private._`
    });
  }

  if (sub === "off") {
    const cfg = readAutoReplyConfig();
    if (!cfg.enabled) {
      return sock.sendMessage(sender, { text: "⚠️ Auto Reply sudah tidak aktif." });
    }
    cfg.enabled = false;
    saveAutoReplyConfig(cfg);
    console.log(clc.yellow("[AutoReply] Dinyahaktifkan."));
    return sock.sendMessage(sender, { text: "🔴 *AUTO REPLY DINYAHAKTIFKAN*\n\nBot tidak akan balas mesej private secara automatik." });
  }

  if (sub === "set") {
    if (!rest) {
      return sock.sendMessage(sender, {
        text: "⚠️ Sila masukkan teks!\n\n*Contoh:* `.autoreply set Hai! Bot ini hanya untuk owner.`"
      });
    }
    const cfg = readAutoReplyConfig();
    cfg.text  = rest;
    saveAutoReplyConfig(cfg);
    console.log(clc.cyan(`[AutoReply] Teks dikemaskini: ${rest.substring(0, 50)}`));
    return sock.sendMessage(sender, {
      text: `✅ *TEKS AUTO REPLY DIKEMASKINI*\n\n💬 Teks baru:\n_${rest}_\n\n_Gunakan \`.autoreply on\` untuk mengaktifkan._`
    });
  }

  if (sub === "clear") {
    autoRepliedUsers.clear();
    console.log(clc.cyan("[AutoReply] Senarai replied users dikosongkan."));
    return sock.sendMessage(sender, {
      text: "✅ *SENARAI RESET*\n\nSemua pengguna boleh menerima auto reply sekali lagi dalam sesi ini."
    });
  }

  return sock.sendMessage(sender, {
    text:
`❓ *SUB-COMMAND TIDAK DIKENALI*

Guna salah satu:
• \`.autoreply on\`
• \`.autoreply off\`
• \`.autoreply set <teks>\`
• \`.autoreply clear\`
• \`.autoreply status\``
  });
}

export default autoreply;
