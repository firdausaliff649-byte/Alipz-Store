/*  
   ⚙️ 𝗗𝗔𝗠𝗫 𝗕𝗟𝗔𝗦𝗧𝗘𝗥 𝗕𝗬 𝗗𝗔𝗠𝗫 ⚙️
   Plugin: X 
*/

import { readHistory, clearHistory } from '../lib/broadcastTracker.js';

async function x(sock, sender, messages) {
    const args = messages.trim().split(' ').slice(1).join(' ').trim();

    if (args === 'clear') {
        clearHistory();
        return sock.sendMessage(sender, {
            text: '🗑️ *HISTORY DIPADAM*\n\nSemua rekod broadcast telah dipadam.'
        });
    }

    const history = readHistory(10);

    if (!history.length) {
        return sock.sendMessage(sender, {
            text: '📭 *TIADA HISTORY*\n\nBelum ada rekod broadcast.'
        });
    }

    let text = `📜 𝗛𝗜𝗦𝗧𝗢𝗥𝗬 𝗕𝗥𝗢𝗔𝗗𝗖𝗔𝗦𝗧\n\n╔═〔 📊 𝗥𝗘𝗞𝗢𝗗 𝗧𝗘𝗥𝗞𝗜𝗡𝗜 〕══╗\n`;
    history.forEach((h, i) => {
        const rate = h.total > 0 ? ((h.ok / h.total) * 100).toFixed(0) : 0;
        text += `║\n║ #${i + 1} — ${h.date}\n`;
        text += `║ 📝 ${(h.preview || '(Media)').slice(0, 40)}${(h.preview?.length > 40) ? '...' : ''}\n`;
        text += `║ ✅ ${h.ok}/${h.total} (${rate}%) | ❌ ${h.fail} | ⏱ ${h.duration}s\n`;
    });
    text += `╚═════════════════╝\n\n_\`.x clear\` — padam semua rekod_`;

    return sock.sendMessage(sender, { text });
}

export default x;
