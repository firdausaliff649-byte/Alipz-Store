/*  
   ⚙️ 𝗗𝗔𝗠𝗫 𝗕𝗟𝗔𝗦𝗧𝗘𝗥 𝗕𝗬 𝗗𝗔𝗠𝗫 ⚙️
   Plugin: AUTO JOIN
*/

import fs from "fs";
import path from "path";
import { displayTime } from "../lib/utils.js";
import { numberAllowed } from "../config.js";

export default async function autojoin(sock, sender, command) {
    try {
        const args = command.split(" ");
        const totalToJoin = parseInt(args[1]);

        if (!totalToJoin || isNaN(totalToJoin) || totalToJoin < 1) {
            return sock.sendMessage(sender, {
                text: `⚠️ *FORMAT SALAH*\n\n` +
`╭┈┈⬡「 📋 *ᴅᴇᴛᴀɪʟ ᴘᴇʀɪɴᴛᴀʜ* 」\n` +
`┃ 📝 Syntax: \`.autojoin <jumlah>\`\n` +
`┃ 💡 Contoh: \`.autojoin 3\`\n` +
`┃\n` +
`┃ ⚠️ Jumlah minimal: 1 group\n` +
`╰┈┈⬡\n\n` +
`© ᴅᴀᴍx ʙʟᴀsᴛᴇʀ | ɴᴇxᴛ-ɢᴇɴ ʙᴏᴛ`
            });
        }

        const dbPath = path.join(process.cwd(), "DATABASE", "data_grub.json");

        if (!fs.existsSync(dbPath)) {
            return sock.sendMessage(sender, {
                text: "❌ *DATABASE ERROR*\n\n📂 File data_grub.json tidak ditemukan.\n💡 Pastikan database sudah dibuat."
            });
        }

        let links;
        try {
            links = JSON.parse(fs.readFileSync(dbPath, "utf8"));
        } catch {
            return sock.sendMessage(sender, {
                text: "❌ *DATABASE ERROR*\n\n📂 Gagal membaca data_grub.json.\n💡 File mungkin rosak."
            });
        }

        if (!Array.isArray(links) || !links.length) {
            return sock.sendMessage(sender, {
                text: "❌ *DATABASE KOSONG*\n\n📭 Tidak ada link group dalam database.\n💡 Tambahkan link terlebih dahulu."
            });
        }

        await sock.sendMessage(sender, {
            text: `🚀 *AUTOJOIN DIMULAI*\n\n` +
                  `📊 Target: ${totalToJoin} group\n` +
                  `📦 Total link tersedia: ${links.length}\n` +
                  `⏳ Estimasi waktu: ~${Math.ceil(totalToJoin * 15 / 60)} menit\n\n` +
                  `⚙️ Proses sedang berjalan...`
        });

        let joined = 0;
        let failed = 0;
        const failedLinks = [];

        for (let i = 0; i < links.length; i++) {
            if (joined >= totalToJoin) break;

            const link = links[i];
            if (typeof link !== "string") continue;

            const code = link.split("https://chat.whatsapp.com/")[1];

            if (!code) {
                failed++;
                failedLinks.push({ link, reason: "Invalid link format" });
                continue;
            }

            try {
                const result = await sock.groupAcceptInvite(code);
                joined++;

                const botNumber = sock?.user?.id
                    ? sock.user.id.split(":")[0].split("@")[0]
                    : null;

                const notifyTargets = [...numberAllowed];
                if (botNumber && !notifyTargets.includes(botNumber)) {
                    notifyTargets.push(botNumber);
                }

                for (const owner of notifyTargets) {
                    await sock.sendMessage(owner + "@s.whatsapp.net", {
                        text: `✅ *BERHASIL JOIN GROUP*\n\n` +
                              `📍 Progress: ${joined}/${totalToJoin}\n` +
                              `🕒 Waktu: ${displayTime()}\n` +
                              `🔗 Link: ${link}\n` +
                              `🆔 Group ID: ${result}\n\n` +
                              `⏳ Delay 15 detik ke group berikutnya...`
                    }).catch(() => {});
                }

                if (joined < totalToJoin) {
                    await new Promise(r => setTimeout(r, 15000));
                }

            } catch (err) {
                failed++;
                failedLinks.push({ link, reason: err.message });
                console.log(`❌ Gagal join group ${i + 1}:`, err.message);
            }
        }

        let reportText = `✅ *AUTOJOIN SELESAI*\n\n` +
                        `📊 *STATISTIK:*\n` +
                        `• Berhasil: ${joined} group\n` +
                        `• Gagal: ${failed} group\n` +
                        `• Total diproses: ${joined + failed}\n\n` +
                        `🕒 Selesai pada: ${displayTime()}`;

        if (failedLinks.length > 0 && failedLinks.length <= 5) {
            reportText += `\n\n❌ *DAFTAR GAGAL:*\n`;
            failedLinks.forEach((item, idx) => {
                reportText += `\n${idx + 1}. ${item.link}\n   Alasan: ${item.reason}\n`;
            });
        } else if (failedLinks.length > 5) {
            reportText += `\n\n❌ Terdapat ${failedLinks.length} link gagal.\n💾 Detail tersimpan di log.`;
        }

        await sock.sendMessage(sender, { text: reportText });

        if (failedLinks.length > 0) {
            const logPath = path.join(process.cwd(), "DATABASE", "autojoin_failed.json");
            const logData = {
                timestamp: new Date().toISOString(),
                total_failed: failed,
                failed_links: failedLinks
            };
            try {
                fs.writeFileSync(logPath, JSON.stringify(logData, null, 2));
            } catch { /* log fail tak kritikal */ }
        }

    } catch (err) {
        console.error("AUTOJOIN ERROR:", err);
        await sock.sendMessage(sender, {
            text: `⚠️ *SYSTEM ERROR*\n\n` +
                  `❌ Terjadi kesalahan sistem:\n${err.message}\n\n` +
                  `💡 Hubungi developer jika error berlanjut.`
        });
    }
}
