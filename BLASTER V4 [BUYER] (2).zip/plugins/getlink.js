/*  
   ⚙️ 𝗗𝗔𝗠𝗫 𝗕𝗟𝗔𝗦𝗧𝗘𝗥 𝗕𝗬 𝗗𝗔𝗠𝗫 ⚙️
   Plugin: GETLINK
*/

import fs from "fs";
import path from "path";
import os from "os";

export default async function getlink(sock, sender, command) {
    try {
        const dbPath = path.join(process.cwd(), "DATABASE", "data_grub.json");

        if (!fs.existsSync(dbPath)) {
            return sock.sendMessage(sender, {
                text: "❌ *DATABASE ERROR*\n\n📂 File data_grub.json tidak ditemukan.\n💡 Pastikan database sudah dibuat."
            });
        }

        let links;
        try {
            links = JSON.parse(fs.readFileSync(dbPath, "utf8"));
        } catch {
            return sock.sendMessage(sender, {
                text: "❌ *DATABASE ERROR*\n\n📂 Gagal membaca data_grub.json.\n💡 File mungkin rosak."
            });
        }

        if (!Array.isArray(links) || !links.length) {
            return sock.sendMessage(sender, {
                text: "❌ *DATABASE KOSONG*\n\n📭 Tidak ada link dalam database.\n💡 Tambahkan link terlebih dahulu."
            });
        }

        const total      = links.length;
        const senderNumber = sender.split("@")[0];
        const botNumber  = sock?.user?.id
            ? sock.user.id.split(":")[0].split("@")[0]
            : null;
        const isBot      = botNumber && senderNumber === botNumber;
        const userLabel  = isBot ? "Bot" : "Authorized";

        const args    = command.trim().split(/\s+/);
        const subCmd  = args[1]?.toLowerCase();

        if (subCmd === "file") {
            const nowStr = new Date().toLocaleString("ms-MY", {
                timeZone: "Asia/Kuala_Lumpur",
                hour12: false
            });

            let content = `╔══════════════════════════════╗\n`;
            content += `║   DAMX BLASTER — GROUP LINKS  ║\n`;
            content += `╚══════════════════════════════╝\n`;
            content += `Diexport oleh : ${senderNumber}\n`;
            content += `Tarikh        : ${nowStr}\n`;
            content += `Total Link    : ${total}\n`;
            content += `${"═".repeat(35)}\n\n`;

            links.forEach((link, i) => {
                content += `${i + 1}. ${link}\n`;
            });

            content += `\n${"═".repeat(35)}\n`;
            content += `© DAMX BLASTER | t.me/D4mxorx\n`;

            const fileName = `damx_links_${Date.now()}.txt`;
            const tmpPath  = path.join(os.tmpdir(), fileName);
            fs.writeFileSync(tmpPath, content, "utf8");

            await sock.sendMessage(sender, {
                document: fs.readFileSync(tmpPath),
                mimetype: "text/plain",
                fileName: `GroupLinks_${total}_${new Date().toISOString().slice(0,10)}.txt`,
                caption:
`📁 *FILE EXPORT BERJAYA*

┌─────────────────────┐
│ 📊 Total Link : ${total}
│ 📅 Tarikh     : ${nowStr}
│ 👤 Oleh       : ${senderNumber}
└─────────────────────┘

💡 File mengandungi semua link group dalam database.
© ᴅᴀᴍx ʙʟᴀsᴛᴇʀ`
            });

            fs.unlinkSync(tmpPath);
            return;
        }

        const page       = parseInt(subCmd) || 1;
        const perPage    = 60;
        const totalPages = Math.ceil(total / perPage);

        if (page < 1 || page > totalPages) {
            return sock.sendMessage(sender, {
                text:
`⚠️ *HALAMAN TIDAK VALID*

📄 Total halaman: ${totalPages}
💡 Gunakan: .getlink 1 hingga .getlink ${totalPages}

📁 Export semua: .getlink file`
            });
        }

        const startIndex   = (page - 1) * perPage;
        const displayLinks = links.slice(startIndex, startIndex + perPage);

        let text = `╭━━━〔 📦 *DATABASE GROUP LINK* 〕━━━╮\n`;
        text += `┃ 👤 Diakses oleh    : ${senderNumber}\n`;
        text += `┃ 🔐 Status          : ${userLabel}\n`;
        text += `┃ 📊 Total Link      : ${total}\n`;
        text += `┃ 📄 Halaman         : ${page}/${totalPages}\n`;
        text += `┃ 🔢 Link Halaman Ini: ${displayLinks.length}\n`;
        text += `╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯\n\n`;

        displayLinks.forEach((link, i) => {
            text += `🔹 ${startIndex + i + 1}. ${link}\n`;
        });

        text += `\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
        if (page > 1)           text += `⬅️ Sebelumnya : .getlink ${page - 1}\n`;
        if (page < totalPages)  text += `➡️ Seterusnya : .getlink ${page + 1}\n`;

        text += `\n💡 *TIPS:*\n`;
        text += `• .getlink          → halaman 1\n`;
        text += `• .getlink 2        → halaman 2\n`;
        text += `• .getlink file     → export semua sebagai file .txt\n`;

        text += `\n⏰ ${new Date().toLocaleString("ms-MY", {
            timeZone: "Asia/Kuala_Lumpur",
            hour12: false
        })}\n`;
        text += `© ᴅᴀᴍx ʙʟᴀsᴛᴇʀ | ɴᴇxᴛ-ɢᴇɴ ʙᴏᴛ`;

        await sock.sendMessage(sender, { text });

    } catch (err) {
        console.error("GETLINK ERROR:", err);
        await sock.sendMessage(sender, {
            text: `⚠️ *SYSTEM ERROR*\n\n❌ ${err.message}\n\n💡 Hubungi developer jika error berlanjut.`
        });
    }
}
