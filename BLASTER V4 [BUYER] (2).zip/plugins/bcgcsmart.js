/*  
   ⚙️ 𝗗𝗔𝗠𝗫 𝗕𝗟𝗔𝗦𝗧𝗘𝗥 𝗕𝗬 𝗗𝗔𝗠𝗫 ⚙️
   Plugin: BCGC SMART
*/

import clc from 'cli-color';
import fs from 'fs';
import path from 'path';
import cron from 'node-cron';
import { filterBlacklisted } from '../lib/blacklistManager.js';
import { saveFailedList, clearFailedList, sendWithRetry } from '../lib/retryEngine.js';


const SMART_MODE = "FAST"; // "FAST" atau "BRUTAL"
const FORWARD_MODE = true; 

const CONFIG = {
    FAST: {
        BATCH_SIZE: 25,
        DELAY_BETWEEN_BATCHES: 500,
        SEND_TIMEOUT: 6000,
        BATCH_DELAY_JITTER: 150,
        ACK_TIMEOUT_IGNORE: true,
        MAX_RETRIES: 0,
        CONCURRENT_BATCHES: 3,
        PROGRESS_UPDATE_INTERVAL: 1
    },
    BRUTAL: {
        BATCH_SIZE: 45,
        DELAY_BETWEEN_BATCHES: 200,
        SEND_TIMEOUT: 4000,
        BATCH_DELAY_JITTER: 50,
        ACK_TIMEOUT_IGNORE: true,
        MAX_RETRIES: 0,
        CONCURRENT_BATCHES: 5,
        PROGRESS_UPDATE_INTERVAL: 1
    }
};

const config = CONFIG[SMART_MODE];


const SMART_FILE = path.join(process.cwd(), 'DATABASE', 'bcgcsmart.json');
global.bcgcSmartActive = false;
global.bcgcSmartCrons = global.bcgcSmartCrons || {};

class SmartProgressManager {
    constructor(sock, sender, scheduledTime) {
        this.sock = sock;
        this.sender = sender;
        this.scheduledTime = scheduledTime;
        this.stats = {
            ok: 0,
            fail: 0,
            startTime: 0,
            processed: 0,
            total: 0,
            batchesCompleted: 0
        };
        this.progressMessageKey = null;
        this.lastPercentage = -1;
        this.failed = [];
    }

    generateProgressBar(percentage) {
        const barLength = 20;
        const filled = Math.round((percentage / 100) * barLength);
        const empty = barLength - filled;
        return '█'.repeat(filled) + '░'.repeat(empty);
    }

    async updateProgress(force = false) {
        if (this.stats.total === 0) return;

        const percentage = Math.floor((this.stats.processed / this.stats.total) * 100);
        
        if (!force && percentage === this.lastPercentage) return;

        this.lastPercentage = percentage;

        const elapsed = ((Date.now() - this.stats.startTime) / 1000).toFixed(1);
        const bar = this.generateProgressBar(percentage);
        
        const avgTimePerGroup = elapsed / this.stats.processed;
        const remaining = (this.stats.total - this.stats.processed) * avgTimePerGroup;
        const eta = remaining > 0 ? `~${remaining.toFixed(0)}s` : 'Done';

        const text = `📡 𝐁𝐂𝐆𝐂 𝐒𝐌𝐀𝐑𝐓 [${this.scheduledTime}] ⚡

╔═〔 📊 𝗣𝗥𝗢𝗚𝗥𝗘𝗦𝗦 〕══╗
║ ${bar}  ${percentage}%
║
║ 📦 Overall   : ${this.stats.processed}/${this.stats.total} Grup
║ 📋 Batches   : ${this.stats.batchesCompleted}
║ ✅ Success   : ${this.stats.ok}
║ ❌ Failed    : ${this.stats.fail}
║
║ ⏱️ Elapsed   : ${elapsed}s
║ ⏳ ETA       : ${eta}
║ ⚙️ Mode      : ${SMART_MODE}
║ 🔄 Forward   : ${FORWARD_MODE ? 'ON' : 'OFF'}
╚═════════════════╝
`;

        try {
            if (!this.progressMessageKey) {
                const sent = await this.sock.sendMessage(this.sender, { text });
                this.progressMessageKey = sent.key;
            } else {
                await this.sock.sendMessage(this.sender, {
                    text,
                    edit: this.progressMessageKey
                });
            }
        } catch (e) {
            console.log(clc.yellow("Progress edit gagal:", e.message));
        }
    }

    incrementSuccess() {
        this.stats.ok++;
        this.stats.processed++;
    }

    incrementFail(groupId) {
        this.stats.fail++;
        this.stats.processed++;
        this.failed.push(groupId);
    }

    completeBatch() {
        this.stats.batchesCompleted++;
    }

    setTotal(total) {
        this.stats.total = total;
        this.stats.startTime = Date.now();
    }

    getStats() {
        return { ...this.stats, failed: this.failed };
    }
}

function parseTime(timeStr) {
    const cleanTime = timeStr.toLowerCase().trim();
    let match = cleanTime.match(/^(\d{1,2}):?(\d{0,2})(pg|pgt|ptg|pm)$/);
    
    if (!match) return null;
    
    let hour = parseInt(match[1]);
    let minute = match[2] ? parseInt(match[2]) : 0;
    const period = match[3];
    
    if (isNaN(hour) || isNaN(minute) || minute > 59) return null;
    
    let hour24 = hour;
    
    if (period === 'pg') {
        if (hour === 12) hour24 = 12;
        else if (hour >= 1 && hour <= 11) hour24 = hour;
        else return null;
    } else if (period === 'pgt' || period === 'ptg') {
        if (hour >= 1 && hour <= 7) hour24 = hour + 12;
        else return null;
    } else if (period === 'pm') {
        if (hour >= 7 && hour <= 11) hour24 = hour + 12;
        else if (hour === 12) hour24 = 0;
        else if (hour >= 1 && hour <= 6) hour24 = hour;
        else return null;
    }
    
    const cronExpression = `${minute} ${hour24} * * *`;
    
    return {
        original: timeStr,
        hour24: hour24,
        minute: minute,
        cronExpression: cronExpression,
        displayTime: `${hour24.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`
    };
}

function ensureSmartFile() {
    const dbDir = path.join(process.cwd(), 'DATABASE');
    if (!fs.existsSync(dbDir)) {
        fs.mkdirSync(dbDir, { recursive: true });
    }
    if (!fs.existsSync(SMART_FILE)) {
        fs.writeFileSync(SMART_FILE, JSON.stringify(null, null, 2));
    }
}

function readSmartSchedule() {
    ensureSmartFile();
    try {
        const data = fs.readFileSync(SMART_FILE, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        return null;
    }
}

function saveSmartSchedule(schedule) {
    ensureSmartFile();
    try {
        fs.writeFileSync(SMART_FILE, JSON.stringify(schedule, null, 2));
        return true;
    } catch (error) {
        return false;
    }
}

function isRealError(error) {
    if (!error) return false;
    
    const errorMessage = error.message?.toLowerCase() || '';
    const errorString = error.toString().toLowerCase();
    
    const realErrorPatterns = [
        'not found', 'forbidden', 'blocked', 'no internet', 'socket',
        'connection', 'econn', 'invalid', 'auth', 'unauthorized'
    ];
    
    const transientErrorPatterns = [
        'timeout', 'timed out', 'rate limit', 'too many', 'wait',
        'try again', 'temporarily', 'overload', 'busy', 'slow', 'delay'
    ];
    
    for (const pattern of realErrorPatterns) {
        if (errorMessage.includes(pattern) || errorString.includes(pattern)) return true;
    }
    
    for (const pattern of transientErrorPatterns) {
        if (errorMessage.includes(pattern) || errorString.includes(pattern)) return false;
    }
    
    return false;
}

async function sendMessageWithRetry(sock, groupId, payload, maxRetries) {
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
        try {
            const sendPromise = sock.sendMessage(groupId, payload);
            const timeoutPromise = new Promise((_, reject) => {
                setTimeout(() => reject(new Error(`Timeout (${config.SEND_TIMEOUT}ms)`)), 
                         config.SEND_TIMEOUT);
            });

            await Promise.race([sendPromise, timeoutPromise]);
            return { success: true };

        } catch (error) {
            if (!isRealError(error) && config.ACK_TIMEOUT_IGNORE) {
                return { success: true };
            }

            if (attempt < maxRetries) {
                const backoff = Math.min(1000 * Math.pow(2, attempt), 5000);
                await new Promise(resolve => setTimeout(resolve, backoff));
                continue;
            }

            return { success: false, error: error.message };
        }
    }
}

async function processBatch(sock, batch, payload, progressManager) {
    const results = await Promise.allSettled(
        batch.map(async (group) => {
            try {
                const result = await sendMessageWithRetry(
                    sock,
                    group.id,
                    payload,
                    config.MAX_RETRIES
                );
                return { group, result };
            } catch (error) {
                return { group, result: { success: false, error } };
            }
        })
    );

    for (const res of results) {
        if (res.status === 'fulfilled') {
            const { group, result } = res.value;

            if (result.success) {
                progressManager.incrementSuccess();
                console.log(clc.green(`[✓] ${group.name}`));
            } else {
                progressManager.incrementFail(group.id);
                console.log(clc.red(`[✗] ${group.name}: ${result.error || 'Unknown'}`));
            }
        } else {
            progressManager.incrementFail('unknown');
        }
    }

    progressManager.completeBatch();
    await progressManager.updateProgress();
}


async function getAllGroups(sock) {
    try {
        const groups = await sock.groupFetchAllParticipating();
        const allGroups = Object.values(groups).map((group) => ({
            id: group.id,
            name: group.subject
        }));

     
        const filtered = filterBlacklisted(allGroups);
        const skipped = allGroups.length - filtered.length;
        if (skipped > 0) {
            console.log(clc.yellow(`[BCGCSmart] ⛔ Skip ${skipped} group (blacklisted)`));
        }

        return filtered;
    } catch (error) {
        console.error(clc.red("❌ Gagal mengambil grup:"), error);
        return [];
    }
}

async function executeSmartBroadcast(sock, ownerJid, scheduleTime) {
    const schedule = readSmartSchedule();
    
    if (!schedule || !schedule.active) {
        console.log(clc.yellow('[BCGCSmart] No active schedule'));
        return;
    }
    
    console.log(clc.magenta(`\n[BCGCSmart] Executing broadcast at ${scheduleTime}`));
    
    // ✅ allGroups dah auto filter blacklist
    const allGroups = await getAllGroups(sock);
    if (!allGroups.length) {
        console.log(clc.yellow('[BCGCSmart] No groups after blacklist filter'));
        await sock.sendMessage(ownerJid, {
            text: `⚠️ *BCGC SMART [${scheduleTime}]*\n\nTiada group untuk di-blast.\nSemua group mungkin dalam blacklist.`
        });
        return;
    }
    
    const progressManager = new SmartProgressManager(sock, ownerJid, scheduleTime);
    progressManager.setTotal(allGroups.length);
    
    await progressManager.updateProgress(true);
    
   
    let payload;
    if (FORWARD_MODE && schedule.quotedMessage) {
        payload = { forward: schedule.quotedMessage };
    } else {
        payload = { text: schedule.message };
    }
    
    
    const batches = [];
    for (let i = 0; i < allGroups.length; i += config.BATCH_SIZE) {
        batches.push(allGroups.slice(i, i + config.BATCH_SIZE));
    }

    const activePromises = new Set();

    for (let i = 0; i < batches.length; i++) {
        const batch = batches[i];

        while (activePromises.size >= config.CONCURRENT_BATCHES) {
            await Promise.race(activePromises);
        }

        const batchPromise = (async () => {
            await processBatch(sock, batch, payload, progressManager);

            if (i < batches.length - 1) {
                const jitter = Math.random() * config.BATCH_DELAY_JITTER;
                await new Promise(resolve =>
                    setTimeout(resolve, config.DELAY_BETWEEN_BATCHES + jitter)
                );
            }
        })();

        activePromises.add(batchPromise);
        batchPromise.finally(() => activePromises.delete(batchPromise));
    }

    await Promise.all(activePromises);
    await progressManager.updateProgress(true);
    
    const stats = progressManager.getStats();
    const duration = ((Date.now() - stats.startTime) / 1000).toFixed(1);
    
    await sock.sendMessage(ownerJid, {
        text: `✅ *BCGC SMART COMPLETE* [${scheduleTime}]\n\n` +
              `╔═〔 📊 𝗥𝗘𝗦𝗨𝗟𝗧 〕══╗\n` +
              `║ 📊 Total: ${stats.total}\n` +
              `║ ✅ Success: ${stats.ok}\n` +
              `║ ❌ Failed: ${stats.fail}\n` +
              `║ 📈 Rate: ${((stats.ok/stats.total)*100).toFixed(1)}%\n` +
              `║ ⏱️ Time: ${duration}s\n` +
              `╚═════════════════╝`
    });
}

export function startSmartCrons(sock, ownerJid) {
    const schedule = readSmartSchedule();
    
    if (!schedule || !schedule.active) {
        console.log(clc.yellow('[BCGCSmart] No active schedule to start'));
        return;
    }
    
    Object.values(global.bcgcSmartCrons).forEach(cron => cron.stop());
    global.bcgcSmartCrons = {};
    
    schedule.times.forEach((timeObj, index) => {
        const task = cron.schedule(timeObj.cronExpression, () => {
            console.log(clc.magenta(`\n[BCGCSmart] Triggered: ${timeObj.displayTime}`));
            executeSmartBroadcast(sock, ownerJid, timeObj.displayTime);
        }, {
            scheduled: true,
            timezone: "Asia/Kuala_Lumpur"
        });
        
        global.bcgcSmartCrons[index] = task;
        console.log(clc.green(`[BCGCSmart] Scheduled: ${timeObj.displayTime} (${timeObj.original})`));
    });
}

async function bcgcsmart(sock, sender, messages, key, messageEvent) {
    const parts = messages.trim().split(' ');
    const command = parts[1]?.toLowerCase();
    
    const templates = `⏰ *BCGC SMART - Scheduled Broadcast*\n\n` +
`╭┈┈⬡「 📋 *ᴄᴏᴍᴍᴀɴᴅs* 」\n` +
`┃ 📝 *Set Schedule:*\n` +
`┃    \`.bcgcsmart <times> <message>\`\n` +
`┃    Reply pesan → \`.bcgcsmart <times>\`\n` +
`┃\n` +
`┃ 📋 *Status:*\n` +
`┃    \`.bcgcsmart status\`\n` +
`┃\n` +
`┃ 🛑 *Stop:*\n` +
`┃    \`.bcgcsmart stop\`\n` +
`╰┈┈⬡\n\n` +
`⏰ *Format Waktu:*\n` +
`• PG (pagi): 1pg-12pg (1 AM - 12 PM)\n` +
`• PTG (petang): 1ptg-7ptg (1 PM - 7 PM)\n` +
`• PM (malam): 7pm-12pm (7 PM - 12 AM)\n\n` +
`💡 *Contoh:*\n` +
`\`.bcgcsmart 3:30pgt,7:00pm Hello!\`\n` +
`\`.bcgcsmart 6:00pg,12:00pg,6:00ptg Promo!\`\n\n` +
`Reply pesan:\n` +
`Reply → \`.bcgcsmart 3:30pgt,7:00pm\`\n\n` +
`© ᴅᴀᴍx ʙʟᴀsᴛᴇʀ | ɴᴇxᴛ-ɢᴇɴ ʙᴏᴛ`;

    try {
        if (command === 'status') {
            const schedule = readSmartSchedule();
            
            if (!schedule) {
                return await sock.sendMessage(sender, {
                    text: "📋 *BCGC SMART STATUS*\n\n🔴 Tidak ada schedule aktif.\n\nGunakan `.bcgcsmart <times> <message>` untuk setup."
                });
            }
            
            const status = schedule.active ? '🟢 AKTIF' : '🔴 NONAKTIF';
            let text = `📋 *BCGC SMART STATUS*\n\n`;
            text += `${status}\n\n`;
            text += `⏰ *Waktu Broadcast:*\n`;
            schedule.times.forEach((t, i) => {
                text += `${i + 1}. ${t.displayTime} (${t.original})\n`;
            });
            text += `\n📝 *Pesan:*\n${schedule.message.substring(0, 100)}...\n`;
            text += `\n🔄 Forward: ${FORWARD_MODE ? 'ON' : 'OFF'}`;
            
            return await sock.sendMessage(sender, { text });
        }
        
        if (command === 'stop') {
            const schedule = readSmartSchedule();
            
            if (!schedule || !schedule.active) {
                return await sock.sendMessage(sender, {
                    text: "❌ Tidak ada schedule yang berjalan."
                });
            }
            
            schedule.active = false;
            saveSmartSchedule(schedule);
            
            Object.values(global.bcgcSmartCrons).forEach(cron => cron.stop());
            global.bcgcSmartCrons = {};
            
            return await sock.sendMessage(sender, {
                text: "🛑 *BCGC SMART DIHENTIKAN*\n\nScheduled broadcasts telah dinonaktifkan."
            });
        }
        
        if (parts.length < 2) {
            return await sock.sendMessage(sender, { text: templates });
        }
        
        const timesStr = parts[1];
        const timeList = timesStr.split(',').map(t => t.trim());
        
        const parsedTimes = [];
        for (const timeStr of timeList) {
            const parsed = parseTime(timeStr);
            if (!parsed) {
                return await sock.sendMessage(sender, {
                    text: `❌ *FORMAT WAKTU SALAH*\n\n"${timeStr}" tidak valid.\n\n` + templates
                });
            }
            parsedTimes.push(parsed);
        }
        
        const msg = messageEvent.messages?.[0];
        const quoted = msg?.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        
        let finalText = parts.slice(2).join(' ');
        let quotedMessage = null;
        
        if (quoted) {
            const quotedText = quoted.conversation ||
                              quoted.extendedTextMessage?.text ||
                              quoted.imageMessage?.caption ||
                              quoted.videoMessage?.caption;
            
            finalText = quotedText || finalText;
            
            if (FORWARD_MODE) {
                quotedMessage = {
                    key: {
                        remoteJid: msg.message.extendedTextMessage.contextInfo.participant || sender,
                        fromMe: false,
                        id: msg.message.extendedTextMessage.contextInfo.stanzaId || msg.key.id
                    },
                    message: quoted
                };
            }
        }
        
        if (!finalText && !quotedMessage) {
            return await sock.sendMessage(sender, { text: templates });
        }
        
        const newSchedule = {
            times: parsedTimes,
            message: finalText,
            quotedMessage: quotedMessage,
            active: true,
            createdAt: new Date().toISOString(),
            createdBy: sender
        };
        
        if (saveSmartSchedule(newSchedule)) {
            startSmartCrons(sock, sender);
            
            let timesList = parsedTimes.map(t => `• ${t.displayTime} (${t.original})`).join('\n');
            
            await sock.sendMessage(sender, {
                text: `✅ *BCGC SMART DIAKTIFKAN*\n\n` +
                      `⏰ *Waktu Broadcast:*\n${timesList}\n\n` +
                      `📝 *Pesan:*\n${finalText.substring(0, 100)}${finalText.length > 100 ? '...' : ''}\n\n` +
                      `🔄 Forward: ${FORWARD_MODE ? 'ON' : 'OFF'}\n` +
                      `⚙️ Mode: ${SMART_MODE}\n\n` +
                      `Broadcast akan otomatis dikirim setiap hari pada waktu yang ditentukan!`
            });
        }
        
    } catch (error) {
        console.error(clc.red('[BCGCSmart Error]:'), error);
        await sock.sendMessage(sender, {
            text: `❌ *ERROR*\n\n${error.message || 'Unknown error'}`
        });
    }
}

export default bcgcsmart;