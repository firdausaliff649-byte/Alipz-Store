/*  
   ⚙️ 𝗗𝗔𝗠𝗫 𝗕𝗟𝗔𝗦𝗧𝗘𝗥 𝗕𝗬 𝗗𝗔𝗠𝗫 ⚙️
   Plugin: LISTGC
*/

import { setCachedGroups } from '../lib/groupIndexStore.js';
import { readBlacklist } from '../lib/blacklistManager.js';

async function listgc(sock, sender, message) {
    try {
        const groups = await sock.groupFetchAllParticipating();
        const blacklist = readBlacklist();
        const blacklistSet = new Set(blacklist.map(g => g.jid));

        const groupList = Object.values(groups).map(group => ({
            id: group.id,
            name: group.subject,
            size: group.size,
            announce: group.announce
        }));

       
        groupList.sort((a, b) => b.size - a.size);

    
        const indexedList = groupList.map((g, i) => ({ ...g, index: i + 1 }));
        setCachedGroups(indexedList);

        const totalGrub     = groupList.length;
        const grubTerbuka   = groupList.filter(g => !g.announce).length;
        const grubTertutup  = groupList.filter(g => g.announce).length;
        const grubBlacklist = groupList.filter(g => blacklistSet.has(g.id)).length;

        let msg =
`╭───❰  *GROUP LIST*  ❱
│ Total       : *${totalGrub}* Grup
│ 🟢 Terbuka  : *${grubTerbuka}* Grup
│ 🔒 Tertutup : *${grubTertutup}* Grup
│ 🚫 Blacklist: *${grubBlacklist}* Grup
╰───────────❱

*Detail Grup:*
`;

        indexedList.forEach((group) => {
            const status = group.announce ? '🔒 TERTUTUP' : '🟢 TERBUKA';
            const blTag  = blacklistSet.has(group.id) ? ' ⛔BL' : '';
            msg +=
`
*${group.index}. ${group.name}*${blTag}
┇ ID     : \`${group.id}\`
┇ Anggota: ${group.size}
┇ Status : ${status}
`;
        });

        msg += `\n${'─'.repeat(30)}
💡 *Tip Blacklist:*
• Guna nombor  : \`.blbcgc 1,2,3\`
• Guna ID      : \`.blbcgc 120363xxx@g.us\`
• Gabung       : \`.blbcgc 1,2,120363xxx@g.us\`
• Remove       : \`.blbcgc remove 1,2,3\`
• ⛔BL = sudah dalam blacklist`;

        await sock.sendMessage(sender, { text: msg });

    } catch (error) {
        console.error('Gagal mendapatkan daftar grup:', error);
        await sock.sendMessage(sender, { text: '❌ Gagal mengambil daftar grup, cuba lagi nanti.' });
    }
}

export default listgc;
