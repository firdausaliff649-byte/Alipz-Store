/*  
   ⚙️ 𝗗𝗔𝗠𝗫 𝗕𝗟𝗔𝗦𝗧𝗘𝗥 𝗕𝗬 𝗗𝗔𝗠𝗫 ⚙️
   Plugin: AUTOBCGC
*/

import clc from "cli-color";
import fs from "fs";
import path from "path";
import { isImageMessage, downloadAndSaveMedia, readWhitelist } from "../lib/utils.js";
import { saveAutoBCGCStatus, readAutoBCGCStatus } from "../lib/autobcgcStatus.js";
import { filterBlacklisted } from "../lib/blacklistManager.js";
import { initSession, updateGroupStatus, markGroupSkipped, saveHistory, clearSession } from "../lib/broadcastTracker.js";
import { saveFailedList } from "../lib/retryEngine.js";

const AUTO_MODE = "FAST"; // "FAST" atau "BRUTAL"
const FORWARD_MODE = true;

const CONFIG = {
    FAST: {
        BATCH_SIZE: 25,
        DELAY_BETWEEN_BATCHES: 500,
        DELAY_BETWEEN_GROUPS: 0,
        SEND_TIMEOUT: 6000,
        BATCH_DELAY_JITTER: 150,
        ACK_TIMEOUT_IGNORE: true,
        MAX_RETRIES: 0,
        CONCURRENT_BATCHES: 3,
        ROUND_DELAY: 900000,
        MAX_ROUNDS: 0,
        PARTICIPANT_LIMIT: 50,
        ROUND_DELAY_WITH_JITTER: true,
        MIN_ROUND_DELAY: 870000,
        MAX_ROUND_DELAY: 930000,
        PROGRESS_UPDATE_INTERVAL: 1
    },
    BRUTAL: {
        BATCH_SIZE: 45,
        DELAY_BETWEEN_BATCHES: 200,
        DELAY_BETWEEN_GROUPS: 0,
        SEND_TIMEOUT: 4000,
        BATCH_DELAY_JITTER: 50,
        ACK_TIMEOUT_IGNORE: true,
        MAX_RETRIES: 0,
        CONCURRENT_BATCHES: 5,
        ROUND_DELAY: 600000,
        MAX_ROUNDS: 0,
        PARTICIPANT_LIMIT: 30,
        ROUND_DELAY_WITH_JITTER: true,
        MIN_ROUND_DELAY: 570000,
        MAX_ROUND_DELAY: 630000,
        PROGRESS_UPDATE_INTERVAL: 1
    }
};

const config = CONFIG[AUTO_MODE];

function getJeda() {
    return global.autobcgc?.jedaPutaran ?? config.ROUND_DELAY;
}
function getJedaMin() {
    const j = getJeda();
    return Math.max(j - 30000, Math.floor(j * 0.95));
}
function getJedaMax() {
    const j = getJeda();
    return Math.min(j + 30000, Math.ceil(j * 1.05));
}

global.autobcgcRunning = false;
global.autobcgc = global.autobcgc || {
    hideTag: false,
    jedaPutaran: config.ROUND_DELAY
};

class ProgressManager {
    constructor(sock, sender, roundNumber) {
        this.sock = sock;
        this.sender = sender;
        this.roundNumber = roundNumber;
        this.stats = {
            ok: 0,
            fail: 0,
            startTime: 0,
            processed: 0,
            total: 0,
            batchesCompleted: 0
        };
        this.progressMessageKey = null;
        this.lastPercentage = -1;
    }

    generateProgressBar(percentage) {
        const barLength = 20;
        const filled = Math.round((percentage / 100) * barLength);
        const empty = barLength - filled;
        return '█'.repeat(filled) + '░'.repeat(empty);
    }

    async updateProgress(force = false) {
        if (this.stats.total === 0) return;

        const percentage = Math.floor((this.stats.processed / this.stats.total) * 100);

        if (!force && percentage === this.lastPercentage) return;

        this.lastPercentage = percentage;

        const elapsed = ((Date.now() - this.stats.startTime) / 1000).toFixed(1);
        const bar = this.generateProgressBar(percentage);

        const avgTimePerGroup = this.stats.processed > 0 ? elapsed / this.stats.processed : 0;
        const remaining = (this.stats.total - this.stats.processed) * avgTimePerGroup;
        const eta = remaining > 0 ? `~${remaining.toFixed(0)}s` : 'Done';

        const text = `🔄 𝐀𝐔𝐓𝐎𝐁𝐂𝐆𝐂 𝐏𝐔𝐓𝐀𝐑𝐀𝐍 ${this.roundNumber} ⚡

╔═〔 📊 𝗣𝗥𝗢𝗚𝗥𝗘𝗦𝗦 〕══╗
║ ${bar}  ${percentage}%
║
║ 📦 Overall   : ${this.stats.processed}/${this.stats.total} Grup
║ 📋 Batches   : ${this.stats.batchesCompleted}
║ ✅ Success   : ${this.stats.ok}
║ ❌ Failed    : ${this.stats.fail}
║
║ ⏱️ Elapsed   : ${elapsed}s
║ ⏳ ETA       : ${eta}
║ ⚙️ Mode      : ${AUTO_MODE}
║ 🔄 Forward   : ${FORWARD_MODE ? 'ON' : 'OFF'}
╚═════════════════╝
`;

        try {
            if (!this.progressMessageKey) {
                const sent = await this.sock.sendMessage(this.sender, { text });
                this.progressMessageKey = sent.key;
            } else {
                await this.sock.sendMessage(this.sender, {
                    text,
                    edit: this.progressMessageKey
                });
            }
        } catch (e) {
            console.log(clc.yellow("Progress edit gagal:", e.message));
        }
    }

    incrementSuccess() {
        this.stats.ok++;
        this.stats.processed++;
    }

    incrementFail() {
        this.stats.fail++;
        this.stats.processed++;
    }

    completeBatch() {
        this.stats.batchesCompleted++;
    }

    setTotal(total) {
        this.stats.total = total;
        this.stats.startTime = Date.now();
    }

    getStats() {
        return { ...this.stats };
    }
}

function isRealError(error) {
    if (!error) return false;

    const errorMessage = error.message?.toLowerCase() || '';
    const errorString = error.toString().toLowerCase();

    const realErrorPatterns = [
        'not found', 'forbidden', 'blocked', 'no internet', 'socket',
        'connection', 'econn', 'invalid', 'auth', 'unauthorized',
        'participant', 'not in group', 'left', 'banned', 'removed'
    ];

    const transientErrorPatterns = [
        'timeout', 'timed out', 'rate limit', 'too many', 'wait',
        'try again', 'temporarily', 'overload', 'busy', 'slow', 'delay'
    ];

    for (const pattern of realErrorPatterns) {
        if (errorMessage.includes(pattern) || errorString.includes(pattern)) return true;
    }

    for (const pattern of transientErrorPatterns) {
        if (errorMessage.includes(pattern) || errorString.includes(pattern)) return false;
    }

    return false;
}

function formatCountdown(ms) {
    const totalSeconds = Math.floor(ms / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;

    if (minutes > 0) return `${minutes}m ${seconds}s`;
    return `${seconds}s`;
}

async function pauseBetweenRounds(durationMs, sock = null, sender = null, roundNumber = null) {
    console.log(clc.cyan(`⏸️  Pause ${formatCountdown(durationMs)} sebelum putaran berikutnya...`));

    const checkInterval = 5000;
    let remaining = durationMs;

    if (sock && sender && roundNumber) {
        await sock.sendMessage(sender, {
            text: `⏸️ *PAUSE SEBELUM PUTARAN ${roundNumber + 1}*\n\n` +
                  `Menunggu ${formatCountdown(durationMs)} sebelum melanjutkan...\n` +
                  `_Gunakan "autobcgc stop" untuk menghentikan_`
        });
    }

    while (remaining > 0 && global.autobcgcRunning) {
        const waitTime = Math.min(checkInterval, remaining);
        await new Promise(resolve => setTimeout(resolve, waitTime));
        remaining -= waitTime;

        if (remaining > 0 && Math.floor(remaining / 1000) % 30 === 0) {
            const timeLeft = formatCountdown(remaining);
            console.log(clc.blue(`⏳ Waktu tunggu tersisa: ${timeLeft}`));

            if (sock && sender && Math.floor(remaining / 1000) % 60 === 0) {
                const minutesLeft = Math.ceil(remaining / 60000);
                await sock.sendMessage(sender, {
                    text: `⏳ *COUNTDOWN PUTARAN ${roundNumber + 1}*\n\n` +
                          `⏰ ${minutesLeft} menit lagi...\n` +
                          `_Auto broadcast akan dilanjutkan otomatis_`
                }).catch(() => {});
            }
        }
    }

    if (!global.autobcgcRunning) {
        console.log(clc.yellow("⏹️  Pause diinterupsi - AutoBCGC dihentikan"));
        return false;
    }

    console.log(clc.green("▶️  Pause selesai, melanjutkan ke putaran berikutnya"));
    return true;
}

function prepareMentions(participants, limit = config.PARTICIPANT_LIMIT) {
    if (!Array.isArray(participants) || participants.length === 0) return [];

    return participants
        .filter(p => p && p.id && typeof p.id === 'string')
        .map(p => p.id)
        .slice(0, limit);
}

async function sendAutoMessage(sock, group, payload, maxRetries) {
    const { id: groupId, name: groupName } = group;

    for (let attempt = 0; attempt <= maxRetries; attempt++) {
        try {
            const sendPromise = sock.sendMessage(groupId, payload);
            const timeoutPromise = new Promise((_, reject) =>
                setTimeout(() => reject(new Error(`Timeout (${config.SEND_TIMEOUT}ms)`)), config.SEND_TIMEOUT)
            );

            await Promise.race([sendPromise, timeoutPromise]);
            return { success: true };

        } catch (error) {
            if (!isRealError(error) && config.ACK_TIMEOUT_IGNORE) {
                console.log(clc.yellow(`[~] ${groupName}: ${error.message} (dianggap sukses)`));
                return { success: true };
            }

            if (attempt < maxRetries) {
                const backoff = Math.min(2000 * Math.pow(2, attempt), 8000);
                await new Promise(resolve => setTimeout(resolve, backoff));
                continue;
            }

            return { success: false, error: error.message };
        }
    }
}

async function getAllGroups(sock) {
    try {
        const raw = await sock.groupFetchAllParticipating();
        const allGroups = Object.values(raw).map(g => ({
            id: g.id,
            name: g.subject || "Unknown",
            // ✅ Nombor ASLI — terus dari metadata group, bukan random
            participants: Array.isArray(g.participants)
                ? g.participants
                    .filter(p => p?.id && p.id.includes("@s.whatsapp.net"))
                    .map(p => ({
                        id: p.id,
                        number: p.id.split("@")[0].replace(/\D/g, ""),
                        isAdmin: p.admin === "admin" || p.admin === "superadmin"
                    }))
                : [],
            memberCount: Array.isArray(g.participants) ? g.participants.length : 0
        }));

        const filtered = filterBlacklisted(allGroups);
        const skipped = allGroups.length - filtered.length;
        if (skipped > 0) {
            console.log(clc.yellow(`[AutoBCGC] ⛔ Skip ${skipped} group (blacklisted)`));
        }
        return filtered;
    } catch (error) {
        console.error(clc.red("❌ Gagal mengambil grup:"), error);
        return [];
    }
}

async function processBatch(sock, batch, payload, progressManager) {
    const results = await Promise.allSettled(
        batch.map(async (group) => {
            try {
                const result = await sendAutoMessage(
                    sock,
                    group,
                    payload,
                    config.MAX_RETRIES
                );
                return { group, result };
            } catch (error) {
                return { group, result: { success: false, error } };
            }
        })
    );

    for (const res of results) {
        if (res.status === 'fulfilled') {
            const { group, result } = res.value;

            if (result.success) {
                progressManager.incrementSuccess();
                console.log(clc.green(`[✓] ${group.name}`));
            } else {
                progressManager.incrementFail();
                if (!group._skipRetry) failedGroupsThisRound.push({ id: group.id, name: group.name });
                console.log(clc.red(`[✗] ${group.name}: ${result.error || 'Unknown'}`));
            }
        } else {
            progressManager.incrementFail();
            console.log(clc.red(`[✗] Unknown error (promise rejected)`));
        }
    }

    progressManager.completeBatch();
    await progressManager.updateProgress();
}

async function executeBroadcastRound(sock, sender, text, imagePath, quotedMessage, roundNumber) {

    const allGroups = await getAllGroups(sock);
    if (!allGroups.length) {
        return { success: 0, fail: 0, totalGroups: 0, duration: 0 };
    }

    const whitelist = readWhitelist();
    const targetGroups = (whitelist && whitelist.length > 0)
        ? allGroups.filter(group => !whitelist.includes(group.id))
        : allGroups;

    if (targetGroups.length === 0) {
        return { success: 0, fail: 0, totalGroups: 0, duration: 0 };
    }

    const failedGroupsThisRound = [];
    const progressManager = new ProgressManager(sock, sender, roundNumber);
    progressManager.setTotal(targetGroups.length);

    await progressManager.updateProgress(true);

    console.log(clc.magenta(`\n🔄 PUTARAN ${roundNumber} DIMULAI ke ${targetGroups.length} grup`));

    let payload;

    if (FORWARD_MODE && quotedMessage) {
        console.log(clc.cyan("[INFO] Using FORWARD mode for AutoBCGC"));
        payload = { forward: quotedMessage };
    } else {
        console.log(clc.cyan("[INFO] Using DOWNLOAD-UPLOAD mode for AutoBCGC"));

        const mentions = global.autobcgc.hideTag ? prepareMentions(targetGroups[0]?.participants || []) : [];
        const basePayload = mentions.length > 0 ? { mentions } : {};

        if (imagePath && fs.existsSync(imagePath)) {
            payload = { image: fs.readFileSync(imagePath), caption: text, ...basePayload };
        } else {
            payload = { text: text, ...basePayload };
        }
    }

    const batches = [];
    for (let i = 0; i < targetGroups.length; i += config.BATCH_SIZE) {
        batches.push(targetGroups.slice(i, i + config.BATCH_SIZE));
    }

    const activePromises = new Set();

    for (let i = 0; i < batches.length; i++) {
        if (!global.autobcgcRunning) break;

        const batch = batches[i];

        while (activePromises.size >= config.CONCURRENT_BATCHES) {
            await Promise.race(activePromises);
        }

        const batchPromise = (async () => {
            await processBatch(sock, batch, payload, progressManager);

            if (i < batches.length - 1 && global.autobcgcRunning) {
                const jitter = Math.random() * config.BATCH_DELAY_JITTER;
                await new Promise(resolve =>
                    setTimeout(resolve, config.DELAY_BETWEEN_BATCHES + jitter)
                );
            }
        })();

        activePromises.add(batchPromise);
        batchPromise.finally(() => activePromises.delete(batchPromise));
    }

    await Promise.all(activePromises);
    await progressManager.updateProgress(true);

    const stats = progressManager.getStats();
    const roundDuration = ((Date.now() - stats.startTime) / 1000).toFixed(1);

    if (failedGroupsThisRound.length > 0) saveFailedList(failedGroupsThisRound);
    console.log(clc.green(`✅ Putaran ${roundNumber} selesai: ${stats.ok} sukses (${roundDuration}s)`));

    return {
        success: stats.ok,
        fail: stats.fail,
        totalGroups: targetGroups.length,
        duration: roundDuration
    };
}

async function autobcgc(sock, sender, messages, key, messageEvent) {
    const parts = messages.trim().split(" ");
    const text = parts.slice(1).join(" ").trim();

    if (text === "stop") {
        if (!global.autobcgcRunning) {
            return sock.sendMessage(sender, {
                text: "❌ AutoBCGC tidak sedang berjalan."
            });
        }

        global.autobcgcRunning = false;
        saveAutoBCGCStatus(false);
        console.log("🛑 AutoBCGC dihentikan oleh pengguna");

        return sock.sendMessage(sender, {
            text: "🛑 *AUTOBCGC DIHENTIKAN*\n\nAuto broadcast telah dihentikan."
        });
    }

    if (text === "status") {
        const status = global.autobcgcRunning ? "🟢 BERJALAN" : "🔴 BERHENTI";
        const savedStatus = readAutoBCGCStatus();

        let statusText = `📊 *STATUS AUTOBCGC*\n\n`;
        statusText += `• Status: ${status}\n`;
        statusText += `• Mode: ${AUTO_MODE}\n`;
        statusText += `• Forward: ${FORWARD_MODE ? 'ON' : 'OFF'}\n`;
        statusText += `• Delay Putaran: ${formatCountdown(getJeda())}\n`;

        if (savedStatus && savedStatus.running) {
            statusText += `• Pesan: ${savedStatus.text?.substring(0, 50)}${savedStatus.text?.length > 50 ? '...' : ''}\n`;
        }

        statusText += `\n_Use "autobcgc stop" untuk menghentikan_`;

        return sock.sendMessage(sender, { text: statusText });
    }

    if (global.autobcgcRunning) {
        return sock.sendMessage(sender, {
            text: "⚠️ *AUTOBCGC SUDAH BERJALAN*\n\nAutoBCGC sedang berjalan. Ketik *autobcgc stop* untuk menghentikan."
        });
    }

    const msg = messageEvent.messages?.[0];
    const quoted = msg?.message?.extendedTextMessage?.contextInfo?.quotedMessage;

    if (!text && !quoted) {
        return sock.sendMessage(sender, {
            text: `⚠️ *FORMAT SALAH*\n\n` +
`╭┈┈⬡「 📋 *ᴅᴇᴛᴀɪʟ ᴘᴇʀɪɴᴛᴀʜ* 」\n` +
`┃ 🛠 *Perintah:* \`autobcgc <pesan>\`\n` +
`┃ 💡 *Contoh:* \`autobcgc Pengumuman penting\`\n` +
`┃ 🔄 *Reply:* Reply pesan → \`autobcgc\`\n` +
`┃\n` +
`┃ ⏰ *Setiap putaran akan pause ${formatCountdown(getJeda())}*\n` +
`┃ 🔄 *Forward mode: ${FORWARD_MODE ? 'ON' : 'OFF'}*\n` +
`╰┈┈⬡\n\n` +
`© ᴅᴀᴍx ʙʟᴀsᴛᴇʀ | ɴᴇxᴛ-ɢᴇɴ ʙᴏᴛ`
        });
    }

    global.autobcgcRunning = true;

    let imagePath = null;
    let quotedMessage = null;
    let finalText = text;

    if (quoted) {
        const quotedText = quoted.conversation ||
                          quoted.extendedTextMessage?.text ||
                          quoted.imageMessage?.caption ||
                          quoted.videoMessage?.caption;

        finalText = quotedText || text;

        if (FORWARD_MODE) {
            quotedMessage = {
                key: {
                    remoteJid: msg.message.extendedTextMessage?.contextInfo?.participant || sender,
                    fromMe: false,
                    id: msg.message.extendedTextMessage?.contextInfo?.stanzaId || msg.key.id
                },
                message: quoted
            };
        } else if (isImageMessage(messageEvent)) {
            try {
                const filename = `${sender}_${Date.now()}.jpeg`;
                const result = await downloadAndSaveMedia(sock, messageEvent.messages?.[0], filename);
                if (result) imagePath = `./tmp/${filename}`;
            } catch (error) {
                console.error(clc.red("❌ Error saat mengunduh gambar:"), error);
            }
        }
    } else if (isImageMessage(messageEvent)) {
        try {
            const filename = `${sender}_${Date.now()}.jpeg`;
            const result = await downloadAndSaveMedia(sock, messageEvent.messages?.[0], filename);
            if (result) imagePath = `./tmp/${filename}`;
        } catch (error) {
            console.error(clc.red("❌ Error saat mengunduh gambar:"), error);
        }
    }

    saveAutoBCGCStatus(true, finalText, imagePath);

    await sock.sendMessage(sender, { react: { text: "⏰", key } });

    await sock.sendMessage(sender, {
        text: `🚀 *AUTOBCGC DIMULAI*\n\n` +
              `• Mode: ${AUTO_MODE}\n` +
              `• Forward: ${FORWARD_MODE ? 'ON' : 'OFF'}\n` +
              `• Delay Putaran: ${formatCountdown(getJeda())}\n` +
              `• Pesan: ${finalText.substring(0, 100)}${finalText.length > 100 ? '...' : ''}\n` +
              `• Media: ${(imagePath || quotedMessage) ? '✅' : '❌'}\n\n` +
              `_Putaran pertama dimulai sekarang..._`
    });

    let putaran = 1;
    const roundStats = [];
    const startTime = Date.now();

    while (global.autobcgcRunning) {
        if (config.MAX_ROUNDS > 0 && putaran > config.MAX_ROUNDS) {
            console.log(clc.yellow(`⚠️ Maksimum ${config.MAX_ROUNDS} putaran tercapai`));
            break;
        }

        try {
            console.log(clc.magenta(`\n═══════════════════════════════════════`));
            console.log(clc.magenta(`         PUTARAN ${putaran} DIMULAI         `));
            console.log(clc.magenta(`═══════════════════════════════════════`));

            const roundResult = await executeBroadcastRound(
                sock, sender, finalText, imagePath, quotedMessage, putaran
            );
            roundStats.push(roundResult);

            if (roundResult.totalGroups === 0) {
                console.log(clc.yellow("⚠️ Tidak ada grup target, menghentikan..."));
                break;
            }

            const totalSuccess = roundStats.reduce((sum, r) => sum + r.success, 0);
            const totalFail = roundStats.reduce((sum, r) => sum + r.fail, 0);
            const successRate = roundResult.totalGroups > 0
                ? ((roundResult.success / roundResult.totalGroups) * 100).toFixed(1)
                : 0;

            await sock.sendMessage(sender, {
                text: `✅ *PUTARAN ${putaran} SELESAI*\n\n` +
                      `📊 Statistik Putaran ${putaran}:\n` +
                      `• ✅ Sukses: ${roundResult.success}\n` +
                      `• ❌ Gagal: ${roundResult.fail}\n` +
                      `• 📈 Success Rate: ${successRate}%\n` +
                      `• ⏱️ Durasi: ${roundResult.duration}s\n\n` +
                      `📈 Statistik Total:\n` +
                      `• Total Sukses: ${totalSuccess}\n` +
                      `• Total Gagal: ${totalFail}\n` +
                      `• Total Putaran: ${putaran}\n\n` +
                      `⏳ Menunggu ${formatCountdown(getJeda())} untuk putaran berikutnya...`
            });

            if (global.autobcgcRunning) {
                putaran++;

                let delayBeforeNextRound;
                if (true) {
                    delayBeforeNextRound = Math.floor(
                        Math.random() * (getJedaMax() - getJedaMin() + 1)
                    ) + getJedaMin();
                } else {
                    delayBeforeNextRound = getJeda();
                }

                console.log(clc.cyan(`\n⏸️  PAUSE ${formatCountdown(delayBeforeNextRound)} SEBELUM PUTARAN ${putaran}`));

                const continueRunning = await pauseBetweenRounds(
                    delayBeforeNextRound, sock, sender, putaran - 1
                );

                if (!continueRunning) break;
            }

        } catch (roundError) {
            console.error(clc.red(`❌ Error pada putaran ${putaran}:`), roundError);

            await sock.sendMessage(sender, {
                text: `⚠️ *ERROR PADA PUTARAN ${putaran}*\n\n` +
                      `Terjadi error: ${roundError.message || 'Unknown'}\n` +
                      `Menunggu ${formatCountdown(getJeda())} sebelum putaran berikutnya...`
            }).catch(() => {});

            if (global.autobcgcRunning) {
                await new Promise(resolve => setTimeout(resolve, getJeda()));
            }
        }
    }

    global.autobcgcRunning = false;
    saveAutoBCGCStatus(false);

    if (imagePath && fs.existsSync(imagePath)) {
        try {
            fs.unlinkSync(imagePath);
        } catch (cleanupError) {
            console.error(clc.yellow(`⚠️ Gagal cleanup image: ${cleanupError.message}`));
        }
    }

    if (roundStats.length > 0) {
        const totalRounds = roundStats.length;
        const totalSuccess = roundStats.reduce((sum, r) => sum + r.success, 0);
        const totalFail = roundStats.reduce((sum, r) => sum + r.fail, 0);
        const totalDuration = ((Date.now() - startTime) / 1000 / 60).toFixed(1);
        const overallSuccessRate = (totalSuccess + totalFail) > 0
            ? ((totalSuccess / (totalSuccess + totalFail)) * 100).toFixed(1)
            : 0;

        let finalReport = `✅ *AUTOBCGC SELESAI*\n\n`;
        finalReport += `📊 *Statistik Akhir:*\n`;
        finalReport += `• Total Putaran: ${totalRounds}\n`;
        finalReport += `• Total Waktu: ${totalDuration} menit\n`;
        finalReport += `• ✅ Total Sukses: ${totalSuccess}\n`;
        finalReport += `• ❌ Total Gagal: ${totalFail}\n`;
        finalReport += `• 📈 Success Rate: ${overallSuccessRate}%\n\n`;
        finalReport += `🔧 *Konfigurasi:*\n`;
        finalReport += `• Mode: ${AUTO_MODE}\n`;
        finalReport += `• Forward: ${FORWARD_MODE ? 'ON' : 'OFF'}\n`;
        finalReport += `• Delay Putaran: ${formatCountdown(getJeda())}\n`;
        finalReport += `\n_Auto broadcast dengan pause ${formatCountdown(getJeda())} telah selesai_`;

        await sock.sendMessage(sender, { text: finalReport });
    } else {
        await sock.sendMessage(sender, { text: "✅ AutoBCGC dihentikan." });
    }
}

export default autobcgc;
