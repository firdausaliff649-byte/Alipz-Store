/*  
   ⚙️ 𝗗𝗔𝗠𝗫 𝗕𝗟𝗔𝗦𝗧𝗘𝗥 𝗕𝗬 𝗗𝗔𝗠𝗫 ⚙️
   Plugin: BLBCGC
*/

import { addToBlacklist, removeFromBlacklist, readBlacklist } from '../lib/blacklistManager.js';
import { resolveGroupInputs, getCachedGroups } from '../lib/groupIndexStore.js';

async function blbcgc(sock, sender, messages, key, messageEvent) {
    const parts      = messages.trim().split(/\s+/);
    const subCommand = parts[1]?.toLowerCase();

    const templates =
`🚫 *BLACKLIST BLAST GROUP*

╭┈┈⬡「 📋 *COMMANDS* 」
┃
┃ ➕ *Add blacklist (nombor):*
┃    \`.blbcgc 1,2,3\`
┃
┃ ➕ *Add blacklist (ID):*
┃    \`.blbcgc 120363xxx@g.us\`
┃
┃ ➕ *Add blacklist (gabung):*
┃    \`.blbcgc 1,2,120363xxx@g.us\`
┃
┃ ➖ *Remove blacklist:*
┃    \`.blbcgc remove 1,2,3\`
┃    \`.blbcgc remove 120363xxx@g.us\`
┃
┃ 📋 *Senarai blacklist:*
┃    \`.blbcgc list\`
┃
╰┈┈⬡

💡 Guna *.listgc* untuk tengok nombor group
© ᴅᴀᴍx ʙʟᴀsᴛᴇʀ`;

    try {

        if (subCommand === 'list') {
            const list = readBlacklist();

            if (list.length === 0) {
                return await sock.sendMessage(sender, {
                    text: `📋 *BLACKLIST BLAST*\n\n✅ Tiada group dalam blacklist.\n\nGuna \`.blbcgc 1,2,3\` atau \`.listgc\` untuk tengok senarai group.`
                });
            }

            let text = `🚫 *BLACKLIST BLAST GROUP*\n\n`;
            text += `📊 Total: *${list.length} group*\n`;
            text += `${'─'.repeat(30)}\n\n`;

            list.forEach((g, i) => {
                const date = new Date(g.addedAt).toLocaleDateString('ms-MY', {
                    day: '2-digit', month: '2-digit', year: 'numeric'
                });
                text += `*${i + 1}. ${g.name}*\n`;
                text += `┇ ID      : \`${g.jid}\`\n`;
                text += `┇ Ditambah: ${date}\n\n`;
            });

            text += `💡 Remove: \`.blbcgc remove 1,2,3\` atau guna ID group`;
            return await sock.sendMessage(sender, { text });
        }

        if (subCommand === 'remove') {
            const rawInput = parts.slice(2).join(' ').trim();

            if (!rawInput) {
                return await sock.sendMessage(sender, {
                    text: `❌ *Format salah!*\n\nGuna:\n• \`.blbcgc remove 1,2,3\`\n• \`.blbcgc remove 120363xxx@g.us\`\n\nGuna \`.listgc\` untuk tengok nombor group.`
                });
            }

       
            const { results, errors } = resolveGroupInputs(rawInput);

            
            const hasNumberInput = rawInput.split(',').some(t => !isNaN(parseInt(t.trim())));
            const cacheEmpty = getCachedGroups().length === 0;
            if (hasNumberInput && cacheEmpty) {
                return await sock.sendMessage(sender, {
                    text: `⚠️ *Cache group kosong!*\n\nSila jalankan *.listgc* dahulu untuk load nombor group, kemudian cuba semula.`
                });
            }

            if (results.length === 0) {
                const errMsg = errors.join('\n');
                return await sock.sendMessage(sender, {
                    text: `❌ *Tiada group yang valid!*\n\n${errMsg}`
                });
            }

            let successList = [];
            let failList    = [];

            for (const g of results) {
                const result = removeFromBlacklist(g.jid);
                if (result.success) {
                    successList.push(`✅ ${result.removed.name}`);
                } else {
                    failList.push(`❌ ${g.name || g.jid} — ${result.reason}`);
                }
            }

            let text = `🗑️ *REMOVE BLACKLIST*\n\n`;
            if (successList.length > 0) {
                text += `*Berjaya dikeluarkan (${successList.length}):*\n${successList.join('\n')}\n\n`;
            }
            if (failList.length > 0) {
                text += `*Gagal (${failList.length}):*\n${failList.join('\n')}\n\n`;
            }
            if (errors.length > 0) {
                text += `*Input tidak dikenali:*\n${errors.map(e => `⚠️ ${e}`).join('\n')}`;
            }

            return await sock.sendMessage(sender, { text: text.trim() });
        }

      
        if (!subCommand) {
            return await sock.sendMessage(sender, { text: templates });
        }

        
        const rawInput = parts.slice(1).join(' ').trim();

        
        const hasNumberInput = rawInput.split(',').some(t => !isNaN(parseInt(t.trim())));
        const cacheEmpty = getCachedGroups().length === 0;
        if (hasNumberInput && cacheEmpty) {
            return await sock.sendMessage(sender, {
                text: `⚠️ *Cache group kosong!*\n\nSila jalankan *.listgc* dahulu untuk load nombor group, kemudian cuba semula.`
            });
        }

        const { results, errors } = resolveGroupInputs(rawInput);

        if (results.length === 0) {
            const errMsg = errors.length > 0
                ? errors.join('\n')
                : 'Format tidak dikenali. Guna nombor (1,2,3) atau group ID (@g.us).';
            return await sock.sendMessage(sender, {
                text: `❌ *Tiada group yang valid!*\n\n${errMsg}\n\n📌 Guna \`.listgc\` untuk tengok senarai group.`
            });
        }

        let successList = [];
        let failList    = [];

        for (const g of results) {
           
            let groupName = g.name;
            if (!groupName) {
                try {
                    const meta = await sock.groupMetadata(g.jid);
                    groupName = meta.subject || 'Unknown';
                } catch {
                    groupName = 'Unknown';
                }
            }

            const result = addToBlacklist(g.jid, groupName);

            if (result.success) {
                successList.push(`✅ ${groupName}`);
            } else if (result.existing) {
                failList.push(`⚠️ ${result.existing.name} — dah ada dalam blacklist`);
            } else {
                failList.push(`❌ ${groupName || g.jid} — ${result.reason}`);
            }
        }

        let text = `🚫 *BLACKLIST BLAST GROUP*\n\n`;
        if (successList.length > 0) {
            text += `*Berjaya ditambah (${successList.length}):*\n${successList.join('\n')}\n\n`;
            text += `Group ini akan *SKIP* semasa blast.\n\n`;
        }
        if (failList.length > 0) {
            text += `*Gagal / Dah ada (${failList.length}):*\n${failList.join('\n')}\n\n`;
        }
        if (errors.length > 0) {
            text += `*Input tidak dikenali:*\n${errors.map(e => `⚠️ ${e}`).join('\n')}\n\n`;
        }

        text += `💡 Guna \`.blbcgc list\` untuk tengok semua blacklist\n`;
        text += `💡 Guna \`.blbcgc remove 1,2,3\` untuk keluarkan`;

        return await sock.sendMessage(sender, { text: text.trim() });

    } catch (error) {
        console.error('❌ Error blbcgc:', error);
        await sock.sendMessage(sender, {
            text: `❌ *ERROR*\n\n${error.message || 'Unknown error'}`
        });
    }
}

export default blbcgc;
