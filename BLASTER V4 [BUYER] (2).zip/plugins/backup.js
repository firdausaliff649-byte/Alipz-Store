/*  
   ⚙️ 𝗗𝗔𝗠𝗫 𝗕𝗟𝗔𝗦𝗧𝗘𝗥 𝗕𝗬 𝗗𝗔𝗠𝗫 ⚙️
   Plugin: BACKUP
*/

import fs   from "fs";
import path from "path";
import os   from "os";
import { execSync } from "child_process";

const BACKUP_INCLUDES = [
    "plugins",
    "lib",
    "ADDTIONAL",
    "DATABASE",
    "config.js",
    "index.js",
    "package.json",
];

const BACKUP_EXCLUDES = [
    "sessions",
    "node_modules",
    ".bak",
    ".git",
];

function formatSize(bytes) {
    if (bytes < 1024)        return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

function formatDuration(ms) {
    if (ms < 1000) return `${ms}ms`;
    return `${(ms / 1000).toFixed(1)}s`;
}

function nowMYT() {
    return new Date().toLocaleString("ms-MY", {
        timeZone:  "Asia/Kuala_Lumpur",
        hour12:    false,
        dateStyle: "medium",
        timeStyle: "medium"
    });
}

function nowStamp() {
    const d   = new Date();
    const pad = n => String(n).padStart(2, "0");
    return `${d.getFullYear()}${pad(d.getMonth()+1)}${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}`;
}

function countFiles(dirPath) {
    if (!fs.existsSync(dirPath)) return 0;
    const stat = fs.statSync(dirPath);
    if (!stat.isDirectory()) return 1;
    let count = 0;
    const walk = (p) => {
        fs.readdirSync(p).forEach(f => {
            if (BACKUP_EXCLUDES.some(ex => f.includes(ex))) return;
            const fp = path.join(p, f);
            if (fs.statSync(fp).isDirectory()) walk(fp);
            else count++;
        });
    };
    walk(dirPath);
    return count;
}

export default async function backup(sock, sender, messages) {
    const parts  = messages.trim().split(/\s+/);
    const subCmd = parts[1]?.toLowerCase();
    const rootDir = process.cwd();


    if (subCmd === "list") {
        let fileList  = [];
        let totalSize = 0;

        for (const item of BACKUP_INCLUDES) {
            const fullPath = path.join(rootDir, item);
            if (!fs.existsSync(fullPath)) continue;
            const stat = fs.statSync(fullPath);
            if (stat.isDirectory()) {
                const walk = (dir) => {
                    fs.readdirSync(dir).forEach(f => {
                        if (BACKUP_EXCLUDES.some(ex => f.includes(ex))) return;
                        const fp = path.join(dir, f);
                        const s  = fs.statSync(fp);
                        if (s.isDirectory()) walk(fp);
                        else {
                            fileList.push({ name: path.relative(rootDir, fp), size: s.size });
                            totalSize += s.size;
                        }
                    });
                };
                walk(fullPath);
            } else {
                fileList.push({ name: item, size: stat.size });
                totalSize += stat.size;
            }
        }

        let text = `📋 *SENARAI FAIL BACKUP*\n\n`;
        text += `📦 Total: *${fileList.length} fail* (${formatSize(totalSize)})\n`;
        text += `${"─".repeat(32)}\n\n`;
        fileList.forEach((f, i) => {
            text += `${i+1}. \`${f.name}\` — ${formatSize(f.size)}\n`;
        });
        text += `\n💡 Jalankan \`.backup\` untuk mula backup sekarang.`;
        return sock.sendMessage(sender, { text });
    }

    if (subCmd === "help") {
        return sock.sendMessage(sender, {
            text:
`💾 *BACKUP BOT — CARA GUNA*

• \`.backup\`       → backup terus sekarang
• \`.backup list\`  → tengok senarai fail
• \`.backup help\`  → panduan ini

© ᴅᴀᴍx ʙʟᴀsᴛᴇʀ`
        });
    }

    const startTime = Date.now();
    const stamp     = nowStamp();
    const zipName   = `DAMX_BACKUP_${stamp}.zip`;
    const tmpPath   = path.join(os.tmpdir(), zipName);

    
    await sock.sendMessage(sender, {
        text: `⏳ *Backup sedang diproses...*\n\nMengumpul fail & compress jadi .zip\nTunggu sebentar ⏱️`
    });

    try {
       
        const itemsToZip = BACKUP_INCLUDES
            .filter(item => fs.existsSync(path.join(rootDir, item)))
            .join(" ");

       
        const excludeFlags = BACKUP_EXCLUDES
            .map(ex => `--exclude='*${ex}*'`)
            .join(" ");

       
        execSync(
            `cd "${rootDir}" && zip -r "${tmpPath}" ${itemsToZip} ${excludeFlags}`,
            { stdio: "pipe" }
        );

        if (!fs.existsSync(tmpPath)) throw new Error("Fail zip tidak terjana.");

        const zipSize   = fs.statSync(tmpPath).size;
        const duration  = Date.now() - startTime;
        const zipBuffer = fs.readFileSync(tmpPath);

        
        let totalFiles = 0;
        for (const item of BACKUP_INCLUDES) {
            totalFiles += countFiles(path.join(rootDir, item));
        }

        
        await sock.sendMessage(sender, {
            document: zipBuffer,
            mimetype: "application/zip",
            fileName: zipName,
            caption:
`✅ *BACKUP BERJAYA!*

┌────────────────────────────┐
│ 📦 Fail   : ${zipName}
│ 📊 Saiz   : ${formatSize(zipSize)}
│ 📁 Total  : ${totalFiles} fail
│ ⏱️ Masa   : ${formatDuration(duration)}
│ 📅 Tarikh : ${nowMYT()}
└────────────────────────────┘

📂 *Kandungan:*
• plugins/   — semua command bot
• lib/        — semua library
• ADDTIONAL/ — whitelist, blacklist
• DATABASE/  — data & media
• config.js, index.js, package.json

⚠️ Simpan fail ini dengan selamat!

© ᴅᴀᴍx ʙʟᴀsᴛᴇʀ`
        });

        fs.unlinkSync(tmpPath);

    } catch (err) {
        if (fs.existsSync(tmpPath)) fs.unlinkSync(tmpPath);
        console.error("[BACKUP] Error:", err.message);
        await sock.sendMessage(sender, {
            text:
`❌ *BACKUP GAGAL*

Error: ${err.message}

💡 Kemungkinan sebab:
• \`zip\` command tidak ada di server
• Kurang ruang disk
• Permission folder bermasalah

Cuba \`.backup list\` untuk semak fail.

© ᴅᴀᴍx ʙʟᴀsᴛᴇʀ`
        });
    }
}
