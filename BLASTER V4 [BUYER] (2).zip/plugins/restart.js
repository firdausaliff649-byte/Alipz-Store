/*  
   ⚙️ 𝗗𝗔𝗠𝗫 𝗕𝗟𝗔𝗦𝗧𝗘𝗥 𝗕𝗬 𝗗𝗔𝗠𝗫 ⚙️
   Plugin: RESTART
*/

import clc from "cli-color";


const RESTART_DELAY = 3;

export default async function restart(sock, sender, messages) {
    const parts  = messages.trim().split(/\s+/);
    const konfirm = parts[1]?.toLowerCase();

    const nowMY = new Date().toLocaleString("ms-MY", {
        timeZone:  "Asia/Kuala_Lumpur",
        hour12:    false,
        dateStyle: "medium",
        timeStyle: "medium"
    });

   
    if (!konfirm) {
        return sock.sendMessage(sender, {
            text:
`🔄 *RESTART BOT*

⚠️ Adakah anda pasti nak restart bot?

Bot akan:
• Stop semua proses semasa
• Disconnect dari WhatsApp
• Auto reconnect dalam ${RESTART_DELAY} saat

Taip \`.restart yes\` untuk teruskan.
Taip \`.restart no\` untuk batal.

© ᴅᴀᴍx ʙʟᴀsᴛᴇʀ`
        });
    }

    
    if (konfirm === "no" || konfirm === "batal") {
        return sock.sendMessage(sender, {
            text: `✅ *Restart dibatalkan.*\n\nBot terus berjalan seperti biasa.`
        });
    }

    
    if (konfirm === "yes" || konfirm === "ya") {

      
        await sock.sendMessage(sender, {
            text:
`🔄 *RESTART DIMULAKAN*

┌─────────────────────┐
│ ⏰ Masa    : ${nowMY}
│ ⏳ Delay   : ${RESTART_DELAY} saat
│ 🔁 Status  : Restarting...
└─────────────────────┘

Bot akan offline sebentar dan reconnect semula.
Tunggu notifikasi *"Bot Online"* selepas restart.

© ᴅᴀᴍx ʙʟᴀsᴛᴇʀ`
        });

        console.log(clc.yellow.bold(`\n[RESTART] ⚠️  Restart diminta oleh owner pada ${nowMY}`));
        console.log(clc.cyan(`[RESTART] 🔄 Bot akan restart dalam ${RESTART_DELAY} saat...`));

       
        await new Promise(resolve => setTimeout(resolve, RESTART_DELAY * 1000));

        console.log(clc.red.bold("[RESTART] 🔴 Restarting now..."));

        process.exit(0);
        return;
    }

    return sock.sendMessage(sender, {
        text:
`❓ *Input tidak dikenali.*

Guna:
• \`.restart yes\` — teruskan restart
• \`.restart no\`  — batal

© ᴅᴀᴍx ʙʟᴀsᴛᴇʀ`
    });
}
