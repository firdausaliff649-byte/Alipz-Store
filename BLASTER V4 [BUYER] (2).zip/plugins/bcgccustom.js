/*  
   ⚙️ 𝗗𝗔𝗠𝗫 𝗕𝗟𝗔𝗦𝗧𝗘𝗥 𝗕𝗬 𝗗𝗔𝗠𝗫 ⚙️
   Plugin: BCGC CUSTOM 
*/

import clc from "cli-color";
import fs from "fs";
import { isImageMessage, downloadAndSaveMedia, readWhitelist } from "../lib/utils.js";
import { saveFailedList, clearFailedList, executeRetry, sendWithRetry } from "../lib/retryEngine.js";
import { filterBlacklisted } from "../lib/blacklistManager.js";
import { promisify } from "util";

const readFileAsync = promisify(fs.readFile);

const BROADCAST_MODE = "FAST";
const FORWARD_MODE   = true;

const CONFIG = {
  FAST: {
    BATCH_SIZE:              20,
    DELAY_BETWEEN_BATCHES:  500,
    SEND_TIMEOUT:           6000,
    BATCH_DELAY_JITTER:      150,
    ACK_TIMEOUT_IGNORE:     true,
    MAX_RETRIES:               0,
    CONCURRENT_BATCHES:        3,
  },
  BRUTAL: {
    BATCH_SIZE:              40,
    DELAY_BETWEEN_BATCHES:  200,
    SEND_TIMEOUT:           4000,
    BATCH_DELAY_JITTER:      50,
    ACK_TIMEOUT_IGNORE:     true,
    MAX_RETRIES:               0,
    CONCURRENT_BATCHES:        5,
  },
};

const config = CONFIG[BROADCAST_MODE];

function shuffleArray(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

async function getAllGroups(sock) {
  try {
    const groups = await sock.groupFetchAllParticipating();
    const all = Object.values(groups).map((g) => ({
      id: g.id,
      name: g.subject || "Unknown",
      participants: g.participants,
    }));
    return filterBlacklisted(all);
  } catch (e) {
    console.error(clc.red("[BcgcCustom] Gagal ambil grup:"), e.message);
    return [];
  }
}

async function sendToGroup(sock, group, payload) {
  return await sendWithRetry(sock, group.id, payload, {
    maxRetries: config.MAX_RETRIES || 2,
    sendTimeout: config.SEND_TIMEOUT,
    retryDelay: 3000,
    ackTimeoutIgnore: config.ACK_TIMEOUT_IGNORE
  });
}

function generateBar(pct) {
  const len    = 18;
  const filled = Math.round((pct / 100) * len);
  return "█".repeat(filled) + "░".repeat(len - filled);
}

class CustomProgressManager {
  constructor(sock, sender, totalGroups, count) {
    this.sock            = sock;
    this.sender          = sender;
    this.total           = totalGroups;
    this.requested       = count;
    this.ok              = 0;
    this.fail            = 0;
    this.processed       = 0;
    this.failedGroups    = [];
    this.startTime       = Date.now();
    this.msgKey          = null;
    this.lastPct         = -1;
  }

  async update(force = false) {
    if (this.total === 0) return;
    const pct = Math.floor((this.processed / this.total) * 100);
    if (!force && pct === this.lastPct) return;
    this.lastPct = pct;

    const elapsed = ((Date.now() - this.startTime) / 1000).toFixed(1);
    const avg     = this.processed > 0 ? elapsed / this.processed : 0;
    const remaining = (this.total - this.processed) * avg;
    const eta     = remaining > 0 ? `~${remaining.toFixed(0)}s` : "Done";
    const bar     = generateBar(pct);

    const text =
`🎯 𝐁𝐂𝐆𝐂 𝐂𝐔𝐒𝐓𝐎𝐌 ⚡

╔═〔 📊 𝗣𝗥𝗢𝗚𝗥𝗘𝗦𝗦 〕══╗
║ ${bar}  ${pct}%
║
║ 🎯 Dipilih    : ${this.total} / ${this.requested} grup
║ 📦 Diproses  : ${this.processed}/${this.total}
║ ✅ Berjaya   : ${this.ok}
║ ❌ Gagal     : ${this.fail}
║
║ ⏱️ Masa      : ${elapsed}s
║ ⏳ ETA       : ${eta}
║ ⚙️ Mode      : ${BROADCAST_MODE}
╚═════════════════╝
`;
    try {
      if (!this.msgKey) {
        const sent  = await this.sock.sendMessage(this.sender, { text });
        this.msgKey = sent.key;
      } else {
        await this.sock.sendMessage(this.sender, { text, edit: this.msgKey });
      }
    } catch { /* ignore */ }
  }
}

async function broadcastCustom(sock, sender, groups, payload, count) {
  const pm = new CustomProgressManager(sock, sender, groups.length, count);
  await pm.update(true);

  const batches = [];
  for (let i = 0; i < groups.length; i += config.BATCH_SIZE) {
    batches.push(groups.slice(i, i + config.BATCH_SIZE));
  }

  const activePromises = new Set();

  for (let i = 0; i < batches.length; i++) {
    const batch = batches[i];

    while (activePromises.size >= config.CONCURRENT_BATCHES) {
      await Promise.race(activePromises);
    }

    const batchPromise = (async () => {
      const results = await Promise.allSettled(
        batch.map(async (group) => {
          const result = await sendToGroup(sock, group, payload);
          return { group, result };
        })
      );

      for (const res of results) {
        pm.processed++;
        if (res.status === "fulfilled") {
          const { group, result } = res.value;
          if (result.success) {
            pm.ok++;
            console.log(clc.green(`[✓] ${group.name}`));
          } else {
            pm.fail++;
            pm.failedGroups.push({ id: group.id, name: group.name });
            console.log(clc.red(`[✗] ${group.name}: ${result.error || "Unknown"}`));
          }
        } else {
          pm.fail++;
          pm.processed++;
        }
      }

      await pm.update();

      if (i < batches.length - 1) {
        const jitter = Math.random() * config.BATCH_DELAY_JITTER;
        await new Promise((r) => setTimeout(r, config.DELAY_BETWEEN_BATCHES + jitter));
      }
    })();

    activePromises.add(batchPromise);
    batchPromise.finally(() => activePromises.delete(batchPromise));
  }

  await Promise.all(activePromises);
  await pm.update(true);

  if (pm.fail > 0) saveFailedList(pm.failedGroups || []);
  return { ok: pm.ok, fail: pm.fail, total: pm.total, duration: ((Date.now() - pm.startTime) / 1000).toFixed(1), failed: pm.failedGroups || [] };
}

async function bcgccustom(sock, sender, messages, key, messageEvent) {
  const body  = messages.trim();
  const parts = body.split(" ");
  const args  = parts.slice(1);
  const msg   = messageEvent.messages?.[0];

  if (args[0] === "list") {
    const allGroups = await getAllGroups(sock);
    if (!allGroups.length) {
      return sock.sendMessage(sender, { text: "❌ Tiada grup tersedia (semua mungkin dalam blacklist)." });
    }

    const whitelist = readWhitelist();
   
  const available = (whitelist && whitelist.length > 0)
    ? allGroups.filter((g) => !whitelist.includes(g.id))
    : allGroups;

    let listText = `📋 *SENARAI GRUP TERSEDIA*\n\n`;
    listText    += `🗂 Total: ${available.length} grup (blacklisted ditolak)\n\n`;
    available.slice(0, 50).forEach((g, i) => {
      listText += `${i + 1}. ${g.name}\n`;
    });
    if (available.length > 50) listText += `\n... dan ${available.length - 50} lagi`;

    return sock.sendMessage(sender, { text: listText });
  }

  const count = parseInt(args[0], 10);
  if (isNaN(count) || count < 1) {
    return sock.sendMessage(sender, {
      text:
`⚠️ *FORMAT .bcgccustom*

╭┈┈⬡「 📋 *ɪɴғᴏ* 」
┃ 🎯 *Broadcast ke N random grup*
┃
┃ 1️⃣  Reply pesan → \`.bcgccustom 40\`
┃     (Bot pilih 40 grup random)
┃
┃ 2️⃣  Text terus → \`.bcgccustom 40 Teks promosi\`
┃
┃ 3️⃣  Senarai grup → \`.bcgccustom list\`
┃
┃ ⚠️ Grup blacklisted akan dikecualikan
┃ ⚠️ Bot pilih secara rawak dari grup tersedia
╰┈┈⬡

© ᴅᴀᴍx ʙʟᴀsᴛᴇʀ | ɴᴇxᴛ-ɢᴇɴ ʙᴏᴛ`
    });
  }

  const inlineText = args.slice(1).join(" ").trim();
  const quoted     = msg?.message?.extendedTextMessage?.contextInfo?.quotedMessage;

  if (!inlineText && !quoted) {
    return sock.sendMessage(sender, {
      text: "⚠️ Sila reply pesan atau masukkan teks selepas count.\n\n*Contoh:* `.bcgccustom 40 Teks promo anda`"
    });
  }

  const allGroups = await getAllGroups(sock);
  if (!allGroups.length) {
    return sock.sendMessage(sender, { text: "❌ Tiada grup ditemukan." });
  }

  const whitelist = readWhitelist();
  
  const available = (whitelist && whitelist.length > 0)
    ? allGroups.filter((g) => !whitelist.includes(g.id))
    : allGroups;

  if (!available.length) {
    return sock.sendMessage(sender, { text: "⚠️ Semua grup dalam whitelist. Tiada target." });
  }

 
  const shuffled = shuffleArray(available);
  const selected = shuffled.slice(0, Math.min(count, shuffled.length));

  let payload  = null;
  let finalText = inlineText;
  let imagePath = null;

  if (quoted) {
    const quotedText =
      quoted.conversation ||
      quoted.extendedTextMessage?.text ||
      quoted.imageMessage?.caption ||
      quoted.videoMessage?.caption;

    finalText = inlineText || quotedText || "";

    if (FORWARD_MODE) {
      payload = {
        forward: {
          key: {
            remoteJid: msg.message.extendedTextMessage?.contextInfo?.participant || sender,
            fromMe:    false,
            id:        msg.message.extendedTextMessage?.contextInfo?.stanzaId || msg.key.id,
          },
          message: quoted,
        },
      };
    } else if (isImageMessage(messageEvent)) {
      try {
        const filename = `bcgccustom_${Date.now()}.jpeg`;
        const ok       = await downloadAndSaveMedia(sock, msg, filename);
        if (ok) {
          imagePath = `./tmp/${filename}`;
          const buffer = await readFileAsync(imagePath);
          payload = { image: buffer, caption: finalText };
        }
      } catch { /* fallback to text */ }
    }

    if (!payload) payload = { text: finalText };
  } else {
    payload = { text: finalText };
  }

  await sock.sendMessage(sender, {
    text:
`🎯 𝗕𝗖𝗚𝗖 𝗖𝗨𝗦𝗧𝗢𝗠 𝗗𝗜𝗠𝗨𝗟𝗔𝗜

╔═〔 📊 𝗜𝗡𝗙𝗢 〕══╗
║ 🎯 Diminta   : ${count} grup
║ ✅ Tersedia  : ${available.length} grup
║ 🎲 Dipilih   : ${selected.length} grup (rawak)
║ ⚙️ Mode      : ${BROADCAST_MODE}
║ 🔄 Forward   : ${FORWARD_MODE ? "ON" : "OFF"}
╚═════════════════╝

🚀 Memulakan broadcast...`
  });

  console.log(
    clc.magenta(`\n🎯 [BcgcCustom] Broadcast ke ${selected.length}/${available.length} grup (dari ${count} yang diminta)`)
  );

  const stats = await broadcastCustom(sock, sender, selected, payload, count);

 
  if (imagePath && fs.existsSync(imagePath)) {
    try { fs.unlinkSync(imagePath); } catch { /* ignore */ }
  }

  // Auto retry failed
  if (stats.failed && stats.failed.length > 0) {
    await sock.sendMessage(sender, { text: `🔁 *AUTO RETRY*\n\n${stats.failed.length} group gagal — mencuba semula...` });
    let retryOk = 0;
    for (const g of stats.failed) {
      try {
        await Promise.race([sock.sendMessage(g.id, payload), new Promise((_, r) => setTimeout(() => r(new Error('T')), 8000))]);
        retryOk++;
        stats.ok++;
        stats.fail = Math.max(0, stats.fail - 1);
      } catch { /* senyap */ }
      await new Promise(r => setTimeout(r, 1200));
    }
    if (retryOk > 0) await sock.sendMessage(sender, { text: `✅ Retry berjaya: ${retryOk}/${stats.failed.length}` });
  }
  const successRate = stats.total > 0 ? ((stats.ok / stats.total) * 100).toFixed(1) : 0;

  await sock.sendMessage(sender, {
    text:
`✅ 𝗕𝗖𝗚𝗖 𝗖𝗨𝗦𝗧𝗢𝗠 𝗦𝗘𝗟𝗘𝗦𝗔𝗜

╔═〔 📊 𝗥𝗘𝗣𝗢𝗥𝗧 〕══╗
║ 🎯 Diminta   : ${count} grup
║ 🎲 Dipilih   : ${stats.total} grup
║ ✅ Berjaya   : ${stats.ok}
║ ❌ Gagal     : ${stats.fail}
║ 📈 Berjaya % : ${successRate}%
║ ⏱️ Masa      : ${stats.duration}s
╚═════════════════╝

© ᴅᴀᴍx ʙʟᴀsᴛᴇʀ | ɴᴇxᴛ-ɢᴇɴ ʙᴏᴛ`
  });
}

export default bcgccustom;
