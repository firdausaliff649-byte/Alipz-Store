/*  
   ⚙️ 𝗗𝗔𝗠𝗫 𝗕𝗟𝗔𝗦𝗧𝗘𝗥 𝗕𝗬 𝗗𝗔𝗠𝗫 ⚙️
   Plugin: PING
*/

import os from "os";
import { performance } from "perf_hooks";
import { readAutoBCGCStatus } from "../lib/autobcgcStatus.js";
import { readAutoReplyConfig, autoRepliedUsers } from "../lib/utils.js";
import { readBlacklist } from "../lib/blacklistManager.js";
import { getCachedGroups } from "../lib/groupIndexStore.js";

async function ping(sock, sender, message, key, messageEvent) {
    const startTime = performance.now();

    const uptimeSeconds = process.uptime();
    const days    = Math.floor(uptimeSeconds / 86400);
    const hours   = Math.floor((uptimeSeconds % 86400) / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);
    const seconds = Math.floor(uptimeSeconds % 60);
    let uptimeStr = "";
    if (days > 0)    uptimeStr += `${days}d `;
    if (hours > 0)   uptimeStr += `${hours}h `;
    if (minutes > 0) uptimeStr += `${minutes}m `;
    uptimeStr += `${seconds}s`;

    const totalMem  = (os.totalmem() / 1024 / 1024 / 1024).toFixed(2);
    const freeMem   = (os.freemem()  / 1024 / 1024 / 1024).toFixed(2);
    const usedMem   = (totalMem - freeMem).toFixed(2);
    const memPercent = ((usedMem / totalMem) * 100).toFixed(1);
    const memBar    = buildBar(parseFloat(memPercent), 10);

    const cpus     = os.cpus();
    const cpuCores = cpus.length;
    const platform = os.platform();
    const arch     = os.arch();

    const endTime      = performance.now();
    const responseTime = (endTime - startTime).toFixed(2);
    const pingEmoji    = responseTime < 100 ? "🟢" : responseTime < 300 ? "🟡" : "🔴";

    let totalGroup = 0, grubTerbuka = 0, grubTertutup = 0;
    try {
        const groups = await sock.groupFetchAllParticipating();
        const list   = Object.values(groups);
        totalGroup   = list.length;
        grubTerbuka  = list.filter(g => !g.announce).length;
        grubTertutup = list.filter(g => g.announce).length;
    } catch {
        
        const cached = getCachedGroups();
        totalGroup   = cached.length;
        grubTerbuka  = cached.filter(g => !g.announce).length;
        grubTertutup = cached.filter(g =>  g.announce).length;
    }
    const blacklistCount = readBlacklist().length;
    const activeGroup    = totalGroup - blacklistCount;

    const autoBcgcStatus = readAutoBCGCStatus();
    const bcgcRunning    = global.autobcgcRunning || autoBcgcStatus.running || false;
    const jedaPutaran    = global.autobcgc?.jedaPutaran ?? 10000;
    const jedaMins       = (jedaPutaran / 60000).toFixed(1);
    const hidetag        = global.autobcgc?.hidetag ? "Ya" : "Tidak";

    const arConfig    = readAutoReplyConfig();
    const arEnabled   = arConfig.enabled || false;
    const arText      = arConfig.text
        ? (arConfig.text.length > 35 ? arConfig.text.substring(0, 35) + "..." : arConfig.text)
        : "(belum ditetapkan)";
    const arReplied   = autoRepliedUsers?.size ?? 0;

    const prefixList  = (global.prefix || ["."]).join("  ");
    const jedaMs      = global.jeda ?? 100;
    const scriptVer   = global.version ?? "4.0";
    const scriptName  = global.name_script ?? "DAMX BLASTER";

    const nowMY = new Date().toLocaleString("ms-MY", {
        timeZone:  "Asia/Kuala_Lumpur",
        dateStyle: "medium",
        timeStyle: "medium"
    });

    const msg =
`┌━━━━━━━━━━━━━━━━━━━━━━━┐
   ${pingEmoji} *${scriptName}*
   📡 Full System Dashboard
└━━━━━━━━━━━━━━━━━━━━━━━┘

╔══〔 🤖 BOT INFO 〕══╗
║ Versi     : v${scriptVer}
║ Uptime    : ${uptimeStr}
║ Response  : ${responseTime}ms ${pingEmoji}
║ Masa (MY) : ${nowMY}
╚═══════════════════════╝

╔══〔 📊 GROUP STATS 〕══╗
║ Total Group  : ${totalGroup} group
║ 🟢 Terbuka   : ${grubTerbuka} group
║ 🔒 Tertutup  : ${grubTertutup} group
║ 🚫 Blacklist : ${blacklistCount} group
║ ✅ Aktif BC  : ${activeGroup} group
╚═══════════════════════╝

╔══〔 🤖 AUTO BCGC 〕══╗
║ Status    : ${bcgcRunning ? "🟢 SEDANG BERJALAN" : "🔴 TIDAK AKTIF"}
║ Jeda      : ${jedaMins} minit / putaran
║ Hidetag   : ${hidetag}
╚═══════════════════════╝

╔══〔 💬 AUTO REPLY 〕══╗
║ Status    : ${arEnabled ? "🟢 AKTIF" : "🔴 TIDAK AKTIF"}
║ Teks      : ${arText}
║ Dah Reply : ${arReplied} pengguna (sesi ini)
╚═══════════════════════╝

╔══〔 ⚙️ SETTINGS 〕══╗
║ Prefix    : ${prefixList}
║ Jeda BC   : ${jedaMs}ms
╚═══════════════════════╝

╔══〔 🖥️ SISTEM 〕══╗
║ Platform  : ${platform} (${arch})
║ CPU Cores : ${cpuCores} Core
║ RAM       : ${usedMem}GB / ${totalMem}GB
║ ${memBar} ${memPercent}%
╚═══════════════════════╝

© ${scriptName} v${scriptVer}`;

    await sock.sendMessage(sender, { text: msg });
}

function buildBar(percent, length = 10) {
    const filled = Math.round((percent / 100) * length);
    const empty  = length - filled;
    return "▓".repeat(filled) + "░".repeat(empty);
}

export default ping;
