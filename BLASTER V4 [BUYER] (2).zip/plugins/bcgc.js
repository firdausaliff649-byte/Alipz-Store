/*  
   ⚙️ 𝗗𝗔𝗠𝗫 𝗕𝗟𝗔𝗦𝗧𝗘𝗥 𝗕𝗬 𝗗𝗔𝗠𝗫 ⚙️
   Plugin: BCGC
*/

import fs from 'fs';
import { downloadAndSaveMedia, readWhitelist } from '../lib/utils.js';
import { filterBlacklisted } from '../lib/blacklistManager.js';
import { promisify } from 'util';
import { saveFailedList, clearFailedList, executeRetry, sendWithRetry, classifyError } from '../lib/retryEngine.js';
import { saveHistory } from '../lib/broadcastTracker.js';

const unlinkAsync = promisify(fs.unlink);
const readFileAsync = promisify(fs.readFile);

const BROADCAST_MODE = "FAST";
const FORWARD_MODE = true;
const CFG = {
    FAST:   { BATCH_SIZE: 20, DELAY: 600,  TIMEOUT: 8000, JITTER: 200, ACK: true, RETRIES: 2, RETRY_DELAY: 3000, CONCURRENT: 3 },
    BRUTAL: { BATCH_SIZE: 35, DELAY: 300,  TIMEOUT: 5000, JITTER: 80,  ACK: true, RETRIES: 2, RETRY_DELAY: 2000, CONCURRENT: 5 },
};
const cfg = CFG[BROADCAST_MODE];

async function fetchGroups(sock) {
    const raw = await sock.groupFetchAllParticipating();
    const all = Object.values(raw).map(g => ({
        id: g.id,
        name: g.subject || 'Unknown',
        participants: Array.isArray(g.participants)
            ? g.participants.filter(p => p?.id?.includes('@s.whatsapp.net'))
                .map(p => ({ id: p.id, number: p.id.split('@')[0], isAdmin: !!p.admin }))
            : [],
        memberCount: Array.isArray(g.participants) ? g.participants.length : 0
    }));
    return filterBlacklisted(all);
}

class BcgcManager {
    constructor(sock, sender) {
        this.sock = sock;
        this.sender = sender;
        this.stats = { ok: 0, fail: 0, skipped: 0, processed: 0, total: 0 };
        this.failedGroups = [];
        this.progressKey = null;
        this.lastPct = -1;
        this.startTime = 0;
    }

    bar(pct) {
        const n = Math.round((pct / 100) * 18);
        return '█'.repeat(n) + '░'.repeat(18 - n);
    }

    async showProgress(force = false) {
        if (!this.stats.total) return;
        const pct = Math.floor((this.stats.processed / this.stats.total) * 100);
        if (!force && pct === this.lastPct) return;
        this.lastPct = pct;
        const elapsed = ((Date.now() - this.startTime) / 1000).toFixed(1);
        const avg = this.stats.processed > 0 ? (Date.now() - this.startTime) / this.stats.processed : 0;
        const eta = this.stats.processed < this.stats.total ? `~${((this.stats.total - this.stats.processed) * avg / 1000).toFixed(0)}s` : '✅';
        const text =
`📡 𝗕𝗥𝗢𝗔𝗗𝗖𝗔𝗦𝗧 𝗣𝗥𝗢𝗚𝗥𝗘𝗦𝗦 ⚡

╔═〔 📊 𝗦𝗨𝗠𝗠𝗔𝗥𝗬 〕══╗
║ ${this.bar(pct)}  ${pct}%
║
║ 📦 Diproses  : ${this.stats.processed}/${this.stats.total}
║ ✅ Berjaya   : ${this.stats.ok}
║ ❌ Gagal     : ${this.stats.fail}
║ ⏭ Skip       : ${this.stats.skipped}
║
║ ⏱ Elapsed    : ${elapsed}s
║ ⏳ ETA        : ${eta}
║ ⚙️ Mode       : ${BROADCAST_MODE}
╚═════════════════╝`;
        try {
            if (!this.progressKey) {
                const sent = await this.sock.sendMessage(this.sender, { text });
                this.progressKey = sent?.key || null;
            } else {
                await this.sock.sendMessage(this.sender, { text, edit: this.progressKey });
            }
        } catch { /* senyap */ }
    }

    async processBatch(batch, payload) {
        const results = await Promise.allSettled(
            batch.map(group => sendWithRetry(this.sock, group.id, payload, {
                maxRetries: cfg.RETRIES, sendTimeout: cfg.TIMEOUT,
                retryDelay: cfg.RETRY_DELAY, ackTimeoutIgnore: cfg.ACK
            }).then(r => ({ group, result: r })))
        );
        for (const res of results) {
            this.stats.processed++;
            if (res.status === 'fulfilled') {
                const { group, result } = res.value;
                if (result.success) { this.stats.ok++; }
                else if (result.permanent) { this.stats.skipped++; }
                else {
                    this.stats.fail++;
                    this.failedGroups.push({ id: group.id, name: group.name });
                }
            } else { this.stats.fail++; }
        }
        await this.showProgress();
    }

    async broadcast(groups, payload) {
        this.stats.total = groups.length;
        this.startTime = Date.now();
        clearFailedList();
        await this.showProgress(true);
        const batches = [];
        for (let i = 0; i < groups.length; i += cfg.BATCH_SIZE)
            batches.push(groups.slice(i, i + cfg.BATCH_SIZE));
        const active = new Set();
        for (let i = 0; i < batches.length; i++) {
            while (active.size >= cfg.CONCURRENT) await Promise.race(active);
            const p = (async () => {
                await this.processBatch(batches[i], payload);
                if (i < batches.length - 1) {
                    await new Promise(r => setTimeout(r, cfg.DELAY + Math.random() * cfg.JITTER));
                }
            })();
            active.add(p);
            p.finally(() => active.delete(p));
        }
        await Promise.all(active);
        // Simpan failed list untuk retry kemudian
        if (this.failedGroups.length > 0) saveFailedList(this.failedGroups);
        await this.showProgress(true);
    }

    async retryFailed(payload) {
        if (!this.failedGroups.length) return { retried: 0, ok: 0, stillFail: 0 };
        return await executeRetry(this.sock, payload, {
            maxRetries: cfg.RETRIES, sendTimeout: cfg.TIMEOUT,
            retryDelay: cfg.RETRY_DELAY, ackTimeoutIgnore: cfg.ACK
        });
    }

    report(duration) {
        const rate = this.stats.total > 0 ? ((this.stats.ok / this.stats.total) * 100).toFixed(1) : 0;
        return `📡 𝗕𝗥𝗢𝗔𝗗𝗖𝗔𝗦𝗧 𝗖𝗢𝗠𝗣𝗟𝗘𝗧𝗘 ✅\n\n╔═〔 📊 𝗙𝗜𝗡𝗔𝗟 𝗥𝗘𝗣𝗢𝗥𝗧 〕══╗\n║ 🗂 Total Grup  : ${this.stats.total}\n║ ✅ Berjaya     : ${this.stats.ok}\n║ ❌ Gagal       : ${this.stats.fail}\n║ ⏭ Skip (Kick) : ${this.stats.skipped}\n║ 📈 Success %   : ${rate}%\n║\n║ ⏱ Duration     : ${duration}s\n║ ⚙️ Mode         : ${BROADCAST_MODE}\n╚═════════════════╝${this.failedGroups.length > 0 ? `\n\n💡 _Guna \`.retrybc\` untuk retry ${this.failedGroups.length} group yang gagal_` : ''}`;
    }
}

async function bcgc(sock, sender, messages, key, messageEvent) {
    const msg = messageEvent.messages?.[0];
    const body = messages.trim();
    if (!body.startsWith('.bcgc')) {
        return sock.sendMessage(sender, {
            text: `⚠️ *FORMAT SALAH*\n\n╭┈┈⬡「 📋 *ɪɴғᴏ* 」\n┃ 1️⃣ Reply pesan → \`.bcgc\`\n┃ 2️⃣ Atau → \`.bcgc pesan kamu\`\n┃ 3️⃣ Forward mode: ${FORWARD_MODE ? '🔄 ON' : '📥 OFF'}\n╰┈┈⬡\n\n© ᴅᴀᴍx ʙʟᴀsᴛᴇʀ | ɴᴇxᴛ-ɢᴇɴ ʙᴏᴛ`
        });
    }
    const args = body.slice(5).trim();
    const quoted = msg?.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    let text = null, mediaBuffer = null, isImage = false, isVideo = false, payload = null;
    if (quoted) {
        if (FORWARD_MODE) {
            text = quoted.conversation || quoted.extendedTextMessage?.text || quoted.imageMessage?.caption || quoted.videoMessage?.caption || '(Forwarded)';
            payload = { forward: { key: { remoteJid: msg.message.extendedTextMessage.contextInfo.participant || sender, fromMe: false, id: msg.message.extendedTextMessage.contextInfo.stanzaId || msg.key.id }, message: quoted } };
        } else {
            text = quoted.conversation || quoted.extendedTextMessage?.text || quoted.imageMessage?.caption || quoted.videoMessage?.caption;
            const hasMedia = quoted.imageMessage || quoted.videoMessage || quoted.documentMessage;
            if (hasMedia) {
                try {
                    const ext = quoted.videoMessage ? 'mp4' : quoted.documentMessage ? (quoted.documentMessage.fileName?.split('.').pop() || 'bin') : 'jpg';
                    const filename = `${sender}_${Date.now()}.${ext}`;
                    const ok = await downloadAndSaveMedia(sock, { key: { remoteJid: sender }, message: quoted }, filename);
                    if (ok) { mediaBuffer = await readFileAsync(`./tmp/${filename}`); await unlinkAsync(`./tmp/${filename}`).catch(() => {}); isImage = !!quoted.imageMessage; isVideo = !!quoted.videoMessage; }
                } catch { return sock.sendMessage(sender, { text: '❌ Gagal muat turun media.' }); }
            }
            if (mediaBuffer) {
                if (isImage) payload = { image: mediaBuffer, caption: text || '' };
                else if (isVideo) payload = { video: mediaBuffer, caption: text || '' };
                else payload = { document: mediaBuffer, fileName: 'file.bin', caption: text || '' };
            } else payload = { text };
        }
    } else if (args) { text = args; payload = { text }; }
    if (!payload) return sock.sendMessage(sender, { text: '⚠️ Sila reply pesan atau taip teks selepas `.bcgc`' });

    let allGroups;
    try { allGroups = await fetchGroups(sock); } catch { allGroups = []; }
    if (!allGroups.length) return sock.sendMessage(sender, { text: '❌ Tiada group ditemukan.' });
    const whitelist = readWhitelist();
    const targets = whitelist?.length > 0 ? allGroups.filter(g => !whitelist.includes(g.id)) : allGroups;
    if (!targets.length) return sock.sendMessage(sender, { text: '⚠️ Semua group dalam whitelist.' });

    await sock.sendMessage(sender, {
        text: `🚀 𝗕𝗥𝗢𝗔𝗗𝗖𝗔𝗦𝗧 𝗦𝗧𝗔𝗥𝗧𝗘𝗗 ⚡\n\n╔═〔 📋 𝗦𝗨𝗠𝗠𝗔𝗥𝗬 〕══╗\n║ 📝 Pesan    : ${text ? text.slice(0, 60) : '(Media)'}\n║ 🗂 Target   : ${targets.length} group\n║ ⚙️ Mode      : ${BROADCAST_MODE}\n║ 🔁 Max Retry: ${cfg.RETRIES}x per group\n╚═════════════════╝\n\n> 📡 Memulakan broadcast...`
    });

    const manager = new BcgcManager(sock, sender);
    const startTime = Date.now();
    await manager.broadcast(targets, payload);

    // Auto retry failed
    if (manager.failedGroups.length > 0) {
        await sock.sendMessage(sender, { text: `🔁 *AUTO RETRY*\n\n${manager.failedGroups.length} group gagal — mencuba semula...` });
        const retryResult = await manager.retryFailed(payload);
        if (retryResult.ok > 0) {
            manager.stats.ok += retryResult.ok;
            manager.stats.fail = Math.max(0, manager.stats.fail - retryResult.ok);
            await sock.sendMessage(sender, { text: `✅ Retry berjaya: ${retryResult.ok}/${retryResult.retried}` });
        }
    }

    const duration = ((Date.now() - startTime) / 1000).toFixed(2);
    saveHistory({ mode: BROADCAST_MODE, total: manager.stats.total, ok: manager.stats.ok, fail: manager.stats.fail, skipped: manager.stats.skipped, duration, preview: text ? text.slice(0, 80) : '(Media)' });
    return sock.sendMessage(sender, { text: manager.report(duration) });
}

export default bcgc;
