/*  
   ⚙️ 𝗗𝗔𝗠𝗫 𝗕𝗟𝗔𝗦𝗧𝗘𝗥 𝗕𝗬 𝗗𝗔𝗠𝗫 ⚙️
   Plugin: SETJEDA
*/

function formatMs(ms) {
    const totalSec = Math.floor(ms / 1000);
    const h = Math.floor(totalSec / 3600);
    const m = Math.floor((totalSec % 3600) / 60);
    const s = totalSec % 60;
    let parts = [];
    if (h > 0) parts.push(`${h} jam`);
    if (m > 0) parts.push(`${m} minit`);
    if (s > 0) parts.push(`${s} saat`);
    return parts.join(' ') || '0s';
}

function parseInput(input) {
    if (!input) return null;
    input = input.trim().toLowerCase();

    const match = input.match(/^(\d+(?:\.\d+)?)(s|m|h)?$/);
    if (!match) return null;

    const val  = parseFloat(match[1]);
    const unit = match[2] || 'm'; 

    switch (unit) {
        case 's': return Math.round(val * 1000);
        case 'm': return Math.round(val * 60 * 1000);
        case 'h': return Math.round(val * 3600 * 1000);
        default:  return null;
    }
}

const MIN_JEDA = 60 * 1000;        
const MAX_JEDA = 24 * 3600 * 1000; 

export default async function setjeda(sock, sender, messages) {
    const parts  = messages.trim().split(/\s+/);
    const input  = parts[1];

    const templates =
`⏱️ *SETJEDA — Ubah Jeda Putaran AutoBCGC*

╭┈┈⬡「 📋 FORMAT 」
┃
┃ .setjeda <nilai><unit>
┃
┃ Unit yang diterima:
┃  • s = saat
┃  • m = minit  ← default
┃  • h = jam
┃
┃ Contoh:
┃  .setjeda 30m   → 30 minit
┃  .setjeda 1h    → 1 jam
┃  .setjeda 90s   → 90 saat
┃  .setjeda 1.5h  → 1 jam 30 minit
┃
┃ Had: minimum 1 minit, maksimum 24 jam
┃
╰┈┈⬡

📌 Jeda semasa: *${formatMs(global.autobcgc?.jedaPutaran ?? 900000)}*`;

   
    if (!input) {
        return sock.sendMessage(sender, { text: templates });
    }

   
    const ms = parseInput(input);

    if (ms === null) {
        return sock.sendMessage(sender, {
            text:
`❌ *FORMAT TIDAK DIKENALI*

Guna format: \`.setjeda <nombor><unit>\`

Contoh:
• \`.setjeda 30m\`
• \`.setjeda 1h\`
• \`.setjeda 90s\`

💡 Taip \`.setjeda\` untuk lihat panduan penuh.`
        });
    }

   
    if (ms < MIN_JEDA) {
        return sock.sendMessage(sender, {
            text: `❌ *Jeda terlalu pendek!*\n\nMinimum jeda ialah *1 minit* untuk elak ban WhatsApp.\n\nCuba: \`.setjeda 1m\` atau lebih.`
        });
    }

    if (ms > MAX_JEDA) {
        return sock.sendMessage(sender, {
            text: `❌ *Jeda terlalu lama!*\n\nMaksimum jeda ialah *24 jam*.\n\nCuba: \`.setjeda 24h\` atau kurang.`
        });
    }

    
    const sebelum = global.autobcgc?.jedaPutaran ?? 900000;

    if (!global.autobcgc) global.autobcgc = {};
    global.autobcgc.jedaPutaran = ms;

    const isRunning = global.autobcgcRunning || false;

    await sock.sendMessage(sender, {
        text:
`✅ *JEDA PUTARAN DIKEMASKINI*

┌─────────────────────┐
│ ⏱️ Sebelum : ${formatMs(sebelum)}
│ ✅ Baru    : ${formatMs(ms)}
└─────────────────────┘

${isRunning
    ? `🟢 AutoBCGC sedang berjalan.\n⚠️ Jeda baru akan diguna pada *putaran seterusnya*.`
    : `🔴 AutoBCGC tidak aktif.\nJeda baru akan diguna apabila AutoBCGC diaktifkan.`}

© ᴅᴀᴍx ʙʟᴀsᴛᴇʀ`
    });
}
