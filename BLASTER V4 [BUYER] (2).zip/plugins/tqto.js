/*  
   ⚙️ 𝗗𝗔𝗠𝗫 𝗕𝗟𝗔𝗦𝗧𝗘𝗥 𝗕𝗬 𝗗𝗔𝗠𝗫 ⚙️
   Plugin: TQTO 
*/

const BANNER_URL = "https://files.catbox.moe/vfzgxk.jpeg"; 

async function tqto(sock, sender, messages, key, messageEvent) {
    const text =
`╭─ ⁅: 𝐓𝐡𝐚𝐧𝐤𝐬 𝐓𝐨 :⁆──◈
║ ╼ *☐ DAMX ( Dev )*
║   _Pengasas Damx Blaster sebalik semua ini._
║ 
║ ╼ *☐ SHAH ( Owner )*
║   _Owner yang paling hemsem dan baik._
║ 
║ ╼ *☐ Fanzz ( Ress )*
║   _Terima kasih kerana menjadi tulang belakang._
║ 
║ ╼ *☐ Cokiz ( Ress )*
║   _Terima kasih kerana menjadi tulang belakang._
║ 
║ ╼ *☐ Yik Fann ( Ress )*
║   _Terima kasih kerana menjadi tulang belakang._
║ 
║ ╼ *☐ Fiquee ( Ress )*
║   _Terima kasih kerana menjadi tulang belakang._
║ 
║ ╼ *☐ Hamzuki ( Ress )*
║   _Terima kasih kerana menjadi tulang belakang._
║ 
║ ╼ *☐ Mih ( Ress )*
║   _Terima kasih kerana menjadi tulang belakang._
║ 
║ ╼ *☐ All Buyer ( Buyer )*
║   _Kepercayaan kalian adalah motivasi kami._
║ 
║ ╼ *☐ All Support ( Support )*
║   _Sokongan kalian buat kami terus maju._
║ 
╰───────────────────◈;`

    try {
      
        await sock.sendMessage(sender, {
            image: { url: BANNER_URL },
            caption: text,
            jpegThumbnail: null,
        });
    } catch {
        
        await sock.sendMessage(sender, { text });
    }
}

export default tqto;
