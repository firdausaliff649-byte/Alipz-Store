/*  
   ⚙️ 𝗗𝗔𝗠𝗫 𝗕𝗟𝗔𝗦𝗧𝗘𝗥 𝗕𝗬 𝗗𝗔𝗠𝗫 ⚙️
   Plugin: RETRYBC 
*/

import { readFailedList, clearFailedList, executeRetry } from '../lib/retryEngine.js';

const RETRY_CFG = {
    sendTimeout: 10000,
    maxRetries: 3,
    retryDelay: 4000,
    ackTimeoutIgnore: true,
};

async function retrybc(sock, sender, messages, key, messageEvent) {
    const msg = messageEvent.messages?.[0];
    const parts = messages.trim().split(' ');
    const sub = parts[1]?.toLowerCase();

   
    if (sub === 'list') {
        const failed = readFailedList();
        if (!failed.length) {
            return sock.sendMessage(sender, {
                text: '✅ *TIADA YANG GAGAL*\n\nSenarai failed kosong. Semua broadcast berjaya!'
            });
        }
        let text = `📋 𝗙𝗔𝗜𝗟𝗘𝗗 𝗟𝗜𝗦𝗧\n\n╔═〔 ❌ ${failed.length} 𝗚𝗔𝗚𝗔𝗟 〕══╗\n`;
        failed.slice(0, 30).forEach((g, i) => {
            text += `║ ${i + 1}. ${g.name || g.id?.split('@')[0] || 'Unknown'}\n`;
        });
        if (failed.length > 30) text += `║ ... dan ${failed.length - 30} lagi\n`;
        text += `╚═════════════════╝\n\n_Guna \`.retrybc\` + reply pesan untuk retry_`;
        return sock.sendMessage(sender, { text });
    }

    
    if (sub === 'clear') {
        clearFailedList();
        return sock.sendMessage(sender, { text: '🗑️ *SENARAI GAGAL DIPADAM*\n\nFailed list telah dikosongkan.' });
    }

   
    const failed = readFailedList();
    if (!failed.length) {
        return sock.sendMessage(sender, {
            text: '✅ *TIADA YANG PERLU DIRETRY*\n\nSenarai failed kosong.\n\n_Jalankan broadcast dahulu menggunakan `.bcgc`, `.bcgccustom`, dll._'
        });
    }

   
    const quoted = msg?.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const inlineText = parts.slice(1).filter(p => p !== 'retry').join(' ').trim();

    let payload = null;

    if (quoted) {
        const quotedText = quoted.conversation || quoted.extendedTextMessage?.text ||
                           quoted.imageMessage?.caption || quoted.videoMessage?.caption || '';
        payload = {
            forward: {
                key: {
                    remoteJid: msg.message.extendedTextMessage?.contextInfo?.participant || sender,
                    fromMe: false,
                    id: msg.message.extendedTextMessage?.contextInfo?.stanzaId || msg.key.id
                },
                message: quoted
            }
        };
        
        const displayText = quotedText.slice(0, 60) || '(Media/Forward)';
        await sock.sendMessage(sender, {
            text: `🔁 𝗥𝗘𝗧𝗥𝗬 𝗕𝗥𝗢𝗔𝗗𝗖𝗔𝗦𝗧\n\n╔═〔 📋 𝗜𝗡𝗙𝗢 〕══╗\n║ 🎯 Target   : ${failed.length} group/kontak gagal\n║ 📝 Pesan    : ${displayText}\n║ 🔁 Max Retry: ${RETRY_CFG.maxRetries}x\n╚═════════════════╝\n\n> Memulakan retry...`
        });
    } else if (inlineText) {
        payload = { text: inlineText };
        await sock.sendMessage(sender, {
            text: `🔁 𝗥𝗘𝗧𝗥𝗬 𝗕𝗥𝗢𝗔𝗗𝗖𝗔𝗦𝗧\n\n╔═〔 📋 𝗜𝗡𝗙𝗢 〕══╗\n║ 🎯 Target   : ${failed.length} group/kontak gagal\n║ 📝 Pesan    : ${inlineText.slice(0, 60)}\n║ 🔁 Max Retry: ${RETRY_CFG.maxRetries}x\n╚═════════════════╝\n\n> Memulakan retry...`
        });
    } else {
        return sock.sendMessage(sender, {
            text: `⚠️ *FORMAT .retrybc*\n\n╭┈┈⬡「 📋 *ɪɴғᴏ* 」\n┃ 1️⃣ Reply pesan → \`.retrybc\`\n┃ 2️⃣ Teks terus → \`.retrybc pesan kamu\`\n┃ 3️⃣ Lihat list → \`.retrybc list\`\n┃ 4️⃣ Kosongkan → \`.retrybc clear\`\n╰┈┈⬡\n\n❌ *${failed.length} group/kontak dalam failed list*`
        });
    }

   
    let ok = 0, stillFail = 0;
    const stillFailList = [];
    let processed = 0;
    let progressKey = null;

    const updateProgress = async (force = false) => {
        const pct = failed.length > 0 ? Math.floor((processed / failed.length) * 100) : 100;
        const n = Math.round((pct / 100) * 18);
        const bar = '█'.repeat(n) + '░'.repeat(18 - n);
        const text = `🔁 𝗥𝗘𝗧𝗥𝗬 𝗣𝗥𝗢𝗚𝗥𝗘𝗦𝗦\n\n╔═〔 📊 𝗦𝗨𝗠𝗠𝗔𝗥𝗬 〕══╗\n║ ${bar}  ${pct}%\n║\n║ 📦 Diproses  : ${processed}/${failed.length}\n║ ✅ Berjaya   : ${ok}\n║ ❌ Masih Gagal: ${stillFail}\n╚═════════════════╝`;
        try {
            if (!progressKey) {
                const sent = await sock.sendMessage(sender, { text });
                progressKey = sent?.key || null;
            } else {
                await sock.sendMessage(sender, { text, edit: progressKey });
            }
        } catch { /* senyap */ }
    };

    await updateProgress(true);

    for (const item of failed) {
        const result = await executeRetry(sock, payload, RETRY_CFG).catch(() => ({ retried: 0, ok: 0, stillFail: 1 }));
     
        try {
            await Promise.race([
                sock.sendMessage(item.id, payload),
                new Promise((_, rej) => setTimeout(() => rej(new Error('Timeout')), RETRY_CFG.sendTimeout))
            ]);
            ok++;
        } catch {
            stillFail++;
            stillFailList.push(item);
        }
        processed++;
        if (processed % 5 === 0 || processed === failed.length) await updateProgress();
        await new Promise(r => setTimeout(r, 1200));
    }

    
    const { saveFailedList } = await import('../lib/retryEngine.js');
    saveFailedList(stillFailList);

    const rate = failed.length > 0 ? ((ok / failed.length) * 100).toFixed(1) : 0;

    return sock.sendMessage(sender, {
        text: `✅ 𝗥𝗘𝗧𝗥𝗬 𝗦𝗘𝗟𝗘𝗦𝗔𝗜\n\n╔═〔 📊 𝗥𝗘𝗣𝗢𝗥𝗧 〕══╗\n║ 🎯 Diretry    : ${failed.length}\n║ ✅ Berjaya    : ${ok}\n║ ❌ Masih Gagal: ${stillFail}\n║ 📈 Success %  : ${rate}%\n╚═════════════════╝${stillFail > 0 ? `\n\n💡 _${stillFail} masih gagal. Guna \`.retrybc list\` untuk lihat._` : '\n\n🎉 _Semua berjaya dihantar!_'}`
    });
}

export default retrybc;
