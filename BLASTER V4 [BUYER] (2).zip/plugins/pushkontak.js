/*  
   ⚙️ 𝗗𝗔𝗠𝗫 𝗕𝗟𝗔𝗦𝗧𝗘𝗥 𝗕𝗬 𝗗𝗔𝗠𝗫 ⚙️
   Plugin: PUSH KONTAK
*/

import clc from 'cli-color';
import { saveFailedList } from '../lib/retryEngine.js';

const PUSH_MODE = "FAST"; // "FAST", "SAFE", atau "BRUTAL"
const FORWARD_MODE = false; 

const CONFIG = {
    FAST: {
        BATCH_SIZE: 25,
        DELAY_BETWEEN_BATCHES: 500,
        SEND_TIMEOUT: 6000,
        BATCH_DELAY_JITTER: 150,
        ACK_TIMEOUT_IGNORE: true,
        MAX_RETRIES: 2,
        CONCURRENT_BATCHES: 3,
        PROGRESS_UPDATE_INTERVAL: 1
    },
    SAFE: {
        BATCH_SIZE: 15,
        DELAY_BETWEEN_BATCHES: 1000,
        SEND_TIMEOUT: 8000,
        BATCH_DELAY_JITTER: 300,
        ACK_TIMEOUT_IGNORE: true,
        MAX_RETRIES: 3,
        CONCURRENT_BATCHES: 2,
        PROGRESS_UPDATE_INTERVAL: 1
    },
    BRUTAL: {
        BATCH_SIZE: 45,
        DELAY_BETWEEN_BATCHES: 200,
        SEND_TIMEOUT: 4000,
        BATCH_DELAY_JITTER: 50,
        ACK_TIMEOUT_IGNORE: true,
        MAX_RETRIES: 0,
        CONCURRENT_BATCHES: 5,
        PROGRESS_UPDATE_INTERVAL: 1
    }
};

const config = CONFIG[PUSH_MODE];
global.pushkontakRunning = false;

class PushProgressManager {
    constructor(sock, sender, groupName) {
        this.sock = sock;
        this.sender = sender;
        this.groupName = groupName;
        this.stats = {
            ok: 0,
            fail: 0,
            startTime: 0,
            processed: 0,
            total: 0,
            batchesCompleted: 0
        };
        this.progressMessageKey = null;
        this.lastPercentage = -1;
        this.failed = [];
    }

    generateProgressBar(percentage) {
        const barLength = 20;
        const filled = Math.round((percentage / 100) * barLength);
        const empty = barLength - filled;
        return '█'.repeat(filled) + '░'.repeat(empty);
    }

    async updateProgress(force = false) {
        if (this.stats.total === 0) return;

        const percentage = Math.floor((this.stats.processed / this.stats.total) * 100);
        
        if (!force && percentage === this.lastPercentage) return;

        this.lastPercentage = percentage;

        const elapsed = ((Date.now() - this.stats.startTime) / 1000).toFixed(1);
        const bar = this.generateProgressBar(percentage);
        
       
        const avgTimePerContact = elapsed / this.stats.processed;
        const remaining = (this.stats.total - this.stats.processed) * avgTimePerContact;
        const eta = remaining > 0 ? `~${remaining.toFixed(0)}s` : 'Done';

        const text = `📤 𝐏𝐔𝐒𝐇 𝐊𝐎𝐍𝐓𝐀𝐊 𝐏𝐑𝐎𝐆𝐑𝐄𝐒𝐒 ⚡

╔═〔 📊 ${this.groupName.substring(0, 20)} 〕══╗
║ ${bar}  ${percentage}%
║
║ 📦 Overall   : ${this.stats.processed}/${this.stats.total} Kontak
║ 📋 Batches   : ${this.stats.batchesCompleted}
║ ✅ Success   : ${this.stats.ok}
║ ❌ Failed    : ${this.stats.fail}
║
║ ⏱️ Elapsed   : ${elapsed}s
║ ⏳ ETA       : ${eta}
║ ⚙️ Mode      : ${PUSH_MODE}
║ 🔄 Forward   : ${FORWARD_MODE ? 'ON' : 'OFF'}
╚═════════════════╝

_Type "pushkontak stop" untuk membatalkan_
`;

        try {
            if (!this.progressMessageKey) {
                const sent = await this.sock.sendMessage(this.sender, { text });
                this.progressMessageKey = sent.key;
            } else {
                await this.sock.sendMessage(this.sender, {
                    text,
                    edit: this.progressMessageKey
                });
            }
        } catch (e) {
            console.log(clc.yellow("Progress edit gagal:", e.message));
        }
    }

    incrementSuccess() {
        this.stats.ok++;
        this.stats.processed++;
    }

    incrementFail(contactId) {
        this.stats.fail++;
        this.stats.processed++;
        this.failed.push(contactId);
    }

    completeBatch() {
        this.stats.batchesCompleted++;
    }

    setTotal(total) {
        this.stats.total = total;
        this.stats.startTime = Date.now();
    }

    getStats() {
        return { ...this.stats, failed: this.failed };
    }

    generateReport() {
        const duration = ((Date.now() - this.stats.startTime) / 1000).toFixed(2);
        const successRate = this.stats.total > 0
            ? ((this.stats.ok / this.stats.total) * 100).toFixed(1)
            : 0;

        let report = `📤 𝐏𝐔𝐒𝐇 𝐊𝐎𝐍𝐓𝐀𝐊 𝐂𝐎𝐌𝐏𝐋𝐄𝐓𝐄 ⚡

╔═〔 📊 ${this.groupName.substring(0, 20)} 〕══╗
║ 🗂 Total Kontak : ${this.stats.total}
║ 📋 Batches      : ${this.stats.batchesCompleted}
║ ✅ Success      : ${this.stats.ok}
║ ❌ Failed       : ${this.stats.fail}
║ 📈 Success %    : ${successRate}%
║
║ ⏱️ Duration     : ${duration}s
║ ⚙️ Mode         : ${PUSH_MODE}
║ 🔄 Forward      : ${FORWARD_MODE ? 'ON' : 'OFF'}
╚═════════════════╝
`;

        if (this.failed.length > 0) {
            report += `\n\n❌ Kontak gagal (${this.failed.length}):\n`;
            report += this.failed.slice(0, 10).map(c => c.split('@')[0]).join(', ');
            if (this.failed.length > 10) {
                report += `\n... dan ${this.failed.length - 10} lagi`;
            }
        }

        return report;
    }
}

function isRealError(error) {
    if (!error) return false;
    
    const errorMessage = error.message?.toLowerCase() || '';
    const errorString = error.toString().toLowerCase();
    
    const realErrorPatterns = [
        'not found', 'forbidden', 'blocked', 'no internet', 'socket',
        'connection', 'econn', 'invalid', 'auth', 'unauthorized'
    ];
    
    const transientErrorPatterns = [
        'timeout', 'timed out', 'rate limit', 'too many', 'wait',
        'try again', 'temporarily', 'overload', 'busy', 'slow', 'delay'
    ];
    
    for (const pattern of realErrorPatterns) {
        if (errorMessage.includes(pattern) || errorString.includes(pattern)) {
            return true;
        }
    }
    
    for (const pattern of transientErrorPatterns) {
        if (errorMessage.includes(pattern) || errorString.includes(pattern)) {
            return false;
        }
    }
    
    return false;
}


async function sendMessageWithRetry(sock, contactId, payload, maxRetries) {
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
        try {
            const sendPromise = sock.sendMessage(contactId, payload);
            const timeoutPromise = new Promise((_, reject) => {
                setTimeout(() => reject(new Error(`Timeout (${config.SEND_TIMEOUT}ms)`)), 
                         config.SEND_TIMEOUT);
            });

            await Promise.race([sendPromise, timeoutPromise]);
            return { success: true };

        } catch (error) {
            if (!isRealError(error) && config.ACK_TIMEOUT_IGNORE) {
                console.log(clc.yellow(`[~] ${contactId}: ${error.message} (dianggap sukses)`));
                return { success: true };
            }

            if (attempt < maxRetries) {
                const backoff = Math.min(1000 * Math.pow(2, attempt), 5000);
                await new Promise(resolve => setTimeout(resolve, backoff));
                continue;
            }

            return { success: false, error: error.message };
        }
    }
}

async function processBatch(sock, batch, payload, progressManager) {
    const results = await Promise.allSettled(
        batch.map(async (participant) => {
            try {
                const result = await sendMessageWithRetry(
                    sock,
                    participant.id,
                    payload,
                    config.MAX_RETRIES
                );
                return { participant, result };
            } catch (error) {
                return { participant, result: { success: false, error } };
            }
        })
    );

    for (const res of results) {
        if (res.status === 'fulfilled') {
            const { participant, result } = res.value;

            if (result.success) {
                progressManager.incrementSuccess();
                console.log(clc.green(`[✓] ${participant.id.split('@')[0]}`));
            } else {
                progressManager.incrementFail(participant.id);
                console.log(clc.red(`[✗] ${participant.id.split('@')[0]}: ${result.error || 'Unknown'}`));
            }
        } else {
            progressManager.incrementFail('unknown');
            console.log(clc.red(`[✗] Unknown error (promise rejected)`));
        }
    }

    
    progressManager.completeBatch();
    await progressManager.updateProgress();
}

async function getGroupParticipants(sock, groupId) {
    try {
        const metadata = await sock.groupMetadata(groupId);
        return {
            participants: metadata.participants,
            name: metadata.subject || 'Unknown Group'
        };
    } catch (error) {
        console.error(clc.red(`[ERROR] Gagal mengambil metadata grup ${groupId}:`), error);
        return null;
    }
}

async function pushkontak(sock, sender, message, key, messageEvent) {
    const parts = message.trim().split(" ");

    const templates = `⚠️ *FORMAT SALAH*\n\n` +
`╭┈┈⬡「 📋 *ᴅᴇᴛᴀɪʟ ᴘᴇʀɪɴᴛᴀʜ* 」\n` +
`┃ 🛠 *Perintah:* \`pushkontak <ID_Grup> <pesan>\`\n` +
`┃ 💡 *Contoh:* \`pushkontak 123456789@g.us Save damx store\`\n` +
`┃ 🔄 *Reply:* Reply pesan → \`pushkontak <ID_Grup>\`\n` +
`┃ 🛑 *Stop:* \`pushkontak stop\` untuk membatalkan\n` +
`┃\n` +
`┃ ⚙️ *Mode: ${PUSH_MODE}* | Forward: ${FORWARD_MODE ? 'ON' : 'OFF'}\n` +
`╰┈┈⬡\n\n` +
`© ᴅᴀᴍx ʙʟᴀsᴛᴇʀ | ɴᴇxᴛ-ɢᴇɴ ʙᴏᴛ`;

    // STOP COMMAND
    if (parts[1] === "stop") {
        if (!global.pushkontakRunning) {
            return await sock.sendMessage(sender, {
                text: "❌ Push kontak tidak sedang berjalan."
            });
        }
        
        global.pushkontakRunning = false;
        console.log("🛑 Push kontak dihentikan oleh pengguna");
        
        return await sock.sendMessage(sender, { 
            text: "🛑 *PUSH KONTAK DIHENTIKAN*\n\nProses push kontak telah dibatalkan."
        });
    }

    
    if (parts.length < 2) {
        return await sock.sendMessage(sender, { text: templates });
    }

    const idgrub = parts[1];

    
    if (!idgrub.includes("@g.us")) {
        return await sock.sendMessage(sender, { text: templates });
    }


    if (global.pushkontakRunning) {
        return await sock.sendMessage(sender, {
            text: "⚠️ *PUSH KONTAK SUDAH BERJALAN*\n\nProses push kontak sedang berjalan. Ketik *pushkontak stop* untuk menghentikan."
        });
    }

  
    const msg = messageEvent.messages?.[0];
    const quoted = msg?.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    
    let text = parts.slice(2).join(" ");
    let quotedMessage = null;

    if (quoted) {
        const quotedText = quoted.conversation ||
                          quoted.extendedTextMessage?.text ||
                          quoted.imageMessage?.caption ||
                          quoted.videoMessage?.caption;
        
        text = quotedText || text;

      
        if (FORWARD_MODE) {
            quotedMessage = {
                key: {
                    remoteJid: msg.message.extendedTextMessage.contextInfo.participant || sender,
                    fromMe: false,
                    id: msg.message.extendedTextMessage.contextInfo.stanzaId || msg.key.id
                },
                message: quoted
            };
        }
    }

   
    if (!text && !quotedMessage) {
        return await sock.sendMessage(sender, { text: templates });
    }

   
    global.pushkontakRunning = true;

    try {
        await sock.sendMessage(sender, {
            text: "⏳ *MEMPROSES PERMINTAAN*\n\nMengambil daftar kontak dari grup..."
        });

  
        const groupData = await getGroupParticipants(sock, idgrub);

        if (!groupData || !groupData.participants || groupData.participants.length === 0) {
            global.pushkontakRunning = false;
            return await sock.sendMessage(sender, {
                text: "❌ *ERROR*\n\nTidak dapat mengambil daftar peserta grup. Periksa apakah:\n" +
                      "• Bot masih berada di grup\n" +
                      "• ID grup sudah benar\n" +
                      "• Bot memiliki izin"
            });
        }

        const allParticipants = groupData.participants;
        const groupName = groupData.name;
        const totalMember = allParticipants.length;

   
        const progressManager = new PushProgressManager(sock, sender, groupName);
        progressManager.setTotal(totalMember);

    
        await sock.sendMessage(sender, {
            text: `🚀 *PUSH KONTAK DIMULAI* ⚡\n\n` +
                  `╔═〔 📊 𝗦𝗨𝗠𝗠𝗔𝗥𝗬 〕══╗\n` +
                  `║ 📱 Grup: ${groupName}\n` +
                  `║ 👥 Total: ${totalMember} kontak\n` +
                  `║ 💬 Pesan: ${text.substring(0, 50)}${text.length > 50 ? '...' : ''}\n` +
                  `║ ⚙️ Mode: ${PUSH_MODE}\n` +
                  `║ 🔄 Forward: ${FORWARD_MODE ? 'ON' : 'OFF'}\n` +
                  `║ ⚡ Batch: ${config.BATCH_SIZE} kontak\n` +
                  `╚═════════════════╝\n\n` +
                  `_Memproses..._`
        });

        
        await progressManager.updateProgress(true);

       
        let payload;
        if (FORWARD_MODE && quotedMessage) {
            payload = { forward: quotedMessage };
        } else {
            payload = { text };
        }

    
        const batches = [];
        for (let i = 0; i < allParticipants.length; i += config.BATCH_SIZE) {
            batches.push(allParticipants.slice(i, i + config.BATCH_SIZE));
        }

        const activePromises = new Set();

        for (let i = 0; i < batches.length; i++) {
            if (!global.pushkontakRunning) {
                console.log(clc.yellow("⏹️ Push kontak dihentikan oleh user"));
                break;
            }

            const batch = batches[i];

            while (activePromises.size >= config.CONCURRENT_BATCHES) {
                await Promise.race(activePromises);
            }

            const batchPromise = (async () => {
                await processBatch(sock, batch, payload, progressManager);

                if (i < batches.length - 1 && global.pushkontakRunning) {
                    const jitter = Math.random() * config.BATCH_DELAY_JITTER;
                    await new Promise(resolve =>
                        setTimeout(resolve, config.DELAY_BETWEEN_BATCHES + jitter)
                    );
                }
            })();

            activePromises.add(batchPromise);
            batchPromise.finally(() => activePromises.delete(batchPromise));
        }

        await Promise.all(activePromises);

    
        await progressManager.updateProgress(true);

  
        // Save failed for retrybc
        if (progressManager.failedContacts.length > 0) saveFailedList(progressManager.failedContacts);
        const report = progressManager.generateReport();
        const retryHint = progressManager.failedContacts.length > 0 ? `\n\n💡 _Guna \`.retrybc\` untuk retry ${progressManager.failedContacts.length} kontak gagal_` : '';
        await sock.sendMessage(sender, { text: report + retryHint });

    } catch (mainError) {
        console.error(clc.red("[FATAL] Terjadi kesalahan fatal di fungsi pushkontak:"), mainError);

        await sock.sendMessage(sender, {
            text: "❌ *ERROR*\n\nTerjadi kesalahan tidak terduga saat menjalankan perintah.\n" +
                  `Detail: ${mainError.message || 'Unknown error'}`
        });
    } finally {
        global.pushkontakRunning = false;
    }
}

export default pushkontak;