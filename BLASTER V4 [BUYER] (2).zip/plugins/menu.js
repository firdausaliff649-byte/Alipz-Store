/*  
   ⚙️ 𝗗𝗔𝗠𝗫 𝗕𝗟𝗔𝗦𝗧𝗘𝗥 𝗕𝗬 𝗗𝗔𝗠𝗫 ⚙️
   Plugin: MENU
*/

import fs from "fs";
import path from "path";
import { getVerifiedQuoted, getGreeting, botConfig } from "../lib/utils.js";

export default async function menu(sock, sender, message) {
  try {
    const number   = sender.split("@")[0];
    const greeting = getGreeting();

    const text =
`*${greeting}*
╭━━〔 🤖 𝐃𝐀𝐌𝐗 𝐁𝐋𝐀𝐒𝐓𝐄𝐑 〕━━⬣
┃ Hai @${number} 👋
┃ DAMX BLASTER siap membantu 
╰────────────────⬣

╭─〔 📊 𝐈𝐍𝐅𝐎 𝐁𝐎𝐓 〕
│ ✦ Name : DAMX BLASTER
│ ✦ Version : v4.0
│ ✦ Owner : t.me/D4mxorx
│ ✦ Language : JavaScript
╰────────────────⬣

╭─〔 📌 𝐌𝐄𝐍𝐔 〕
│ 〢 bcgc
│ 〢 bcgccustom
│ 〢 bcgcsmart
│ 〢 autobcgc
│ 〢 retrybc
│ 〢 setjeda
│ 〢 blbcgc
│ 〢 listgc
│ 〢 getlink
│ 〢 autojoin
│ 〢 pushkontak
│ 〢 autoreply
│ 〢 ping
│ 〢 tqto
╰────────────────⬣

© ᴅᴀᴍx ʙʟᴀsᴛᴇʀ | ɴᴇxᴛ-ɢᴇɴ ʙᴏᴛ`;

    await sock.sendMessage(
      sender,
      {
        text,
        contextInfo: {
          mentionedJid: [sender],
          externalAdReply: {
            thumbnailUrl: global.thumbnail,
            title: "ᴅᴀᴍx sᴛᴏʀᴇ | sᴍᴀʀᴛ ʙᴏᴛ sᴇʀᴠɪᴄᴇ 🤖",
            renderLargerThumbnail: true,
            mediaType: 1,
          },
        },
      },
      { quoted: getVerifiedQuoted(botConfig) }
    );

    const audioPath = path.join(process.cwd(), "DATABASE", "d4mxor.mp3");
    if (fs.existsSync(audioPath)) {
      await sock.sendMessage(
        sender,
        { audio: fs.readFileSync(audioPath), mimetype: "audio/mpeg", ptt: false },
        { quoted: getVerifiedQuoted(botConfig) }
      );
    }
  } catch (err) {
    console.error("[Menu] Error:", err.message);
  }
}